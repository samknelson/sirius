# Porting Package — How to Use This

This directory contains **porting packages** for transferring features from a source Replit project to a target project with a newer codebase. These packages exist because direct code merges across diverged codebases are fragile: file paths drift, schemas evolve, conventions change, and library versions differ.

Instead of merging code, each package contains a **specification + reference implementation** that the target project's agent can study and rebuild natively in that codebase's idioms.

## Packages Included

- **`address-overhaul/`** — Append-only address management with source tracking, deliverability status, and primary-priority rules
- **`vdb-pension/`** — GBHET Variable Defined Benefit pension administration with dual accrual models (tiered + contribution_pct), charge plugin chain, actuarial factor tables, and a payout calculator with 70.5 + DoT-to-DoBC AI

Each package is **independent** and can be ported separately.

## Package Structure

Every package follows the same layout:

```
<feature-name>/
├── README.md              # What the feature does, why it exists, dependencies
├── REQUIREMENTS.md        # Business rules, invariants, edge cases
├── SCHEMA.sql             # Framework-neutral DDL (CREATE TABLE, constraints, indexes)
├── API_CONTRACT.md        # Endpoint specs (paths, methods, request/response shapes)
├── ACCEPTANCE_TESTS.md    # Concrete behavioral scenarios the rebuild must pass
├── GOTCHAS.md             # Hard-won lessons from the original implementation
└── reference-code/        # Verbatim copies of source files at original paths
    ├── shared/...
    ├── server/...
    ├── client/...
    └── scripts/...
```

## Recommended Workflow for the Target Agent

1. **Read in order**: `README.md` → `REQUIREMENTS.md` → `SCHEMA.sql` → `API_CONTRACT.md` → `ACCEPTANCE_TESTS.md` → `GOTCHAS.md`. Treat reference code as the authoritative tiebreaker when prose specs are ambiguous.

2. **Build in this order**:
   1. **Schema** — translate `SCHEMA.sql` into the target's ORM (Drizzle, Prisma, etc.) and run a migration. Match column names exactly unless the target has a strong convention forcing renames.
   2. **Storage / data access layer** — port the storage functions from `reference-code/server/storage/` into the target's storage pattern. The business logic (matching, primary promotion, immutability enforcement, soft-delete) must be preserved exactly.
   3. **Services** — port any service-layer modules (validation, provider integrations).
   4. **API routes** — implement the endpoints from `API_CONTRACT.md`. The route paths and request/response shapes are part of the contract; preserve them so frontend code can be ported with minimal changes.
   5. **Frontend** — port the React components last. Adapt to the target's component library if it differs (e.g. shadcn version, form library, query client).

3. **Validate against `ACCEPTANCE_TESTS.md`** — each scenario should be reproducible end-to-end after the port.

4. **Read `GOTCHAS.md` BEFORE writing code** — these are mistakes the original implementation made that took multiple review rounds to fix. Reading them first will save the same rework.

## Handling Naming and Path Differences

The reference code uses paths and naming from the source codebase. The target codebase will likely have different conventions:

- **File paths**: Adapt freely. The path layout is documentation, not contract.
- **Database column names**: Preserve exactly unless the target has a strong reason to differ. Keeping them aligned makes future cross-codebase data comparisons trivial.
- **API endpoint paths**: Preserve exactly. These are part of the contract that frontend code depends on.
- **Function names**: Adapt to target conventions (e.g. `findMatchingAddress` → whatever the target's storage layer uses).
- **Type names**: Adapt to target conventions, but preserve the underlying shape (field names, enum values).

## Handling Dependency Differences

The reference code may depend on host-codebase systems that differ in the target:

- **Access control / policy middleware** — the reference uses `requireAccess('contact.edit', ...)`. The target should map to its own policy primitives.
- **Logging** — the reference uses Winston via a `logger` import. Substitute the target's logger.
- **Database client** — reference uses Drizzle. If the target uses Prisma or another ORM, adapt query syntax but preserve query semantics (which rows are selected, ordering, transaction boundaries).
- **Validation** — reference uses Zod schemas via `drizzle-zod`. Substitute the target's validation library.

## What's Out of Scope

These packages do **not** include:

- Generic codebase migration tooling
- The host's access policy system, logging framework, or storage middleware (those are pre-existing infrastructure in any reasonable codebase)
- Test fixtures or seed data
- UI library setup (shadcn/ui, Tailwind, etc. — those are pre-existing in any modern fullstack project)

## Reporting Issues

If a package's reference code reveals a bug or unclear requirement during the port, file the issue against the **source** project so the spec can be updated for future ports.
