# Address Overhaul — Gotchas & Hard-Won Lessons

These are mistakes the original implementation made that took multiple code-review rounds to fix. Reading them before writing code will save the same rework.

---

## 1. Source must be server-derived, never client-controlled

**Wrong**: Trusting `req.body.source`. A worker portal client could send `source: "admin"` and gain admin-level priority.

**Right**: Each route hard-codes its source:

```typescript
// Admin route
const source: AddressSource = "admin";  // ignored from req.body

// Worker self-service route
const source: AddressSource = "worker_self";  // ignored from req.body
```

The Zod schema may permit `source` (because the storage layer needs it), but the route MUST overwrite it before passing to storage. This is a security boundary, not a styling preference.

---

## 2. Source is NOT overwritten on match — except for `worker_self`

**Wrong (silently corrupts attribution)**:
```typescript
if (existing) {
  await update(existing.id, { source, updatedAt: new Date() });  // overwrites!
}
```

**Right**:
```typescript
if (existing) {
  const matchUpdates: Partial<InsertContactPostal> = { updatedAt: new Date() };

  if (source === "worker_self") {
    // The worker_self exception: stamp ownership and promote
    matchUpdates.source = "worker_self";
    if (!existing.isPrimary) {
      // demote current primary, promote this row
    }
  }
  // For all other sources, do NOT touch existing.source

  await update(existing.id, matchUpdates);
}
```

This matters because an employer feed importing the same address as a worker_self entry must NOT downgrade the source attribution.

---

## 3. Worker_self match path must promote even if currently primary, AND stamp source

This was the subtlest bug: in the match path, when source is `worker_self`, you must always stamp `source = "worker_self"` on the existing row even if it's already primary. Otherwise an admin-sourced primary that the worker confirms will keep `source = "admin"` forever.

The reference handles this by always setting `matchUpdates.source = "worker_self"` whenever the incoming source is `worker_self`, then ALSO promoting if not currently primary.

---

## 4. Deliverability status updates ONLY on `result.valid === true`

**Wrong (silently marks addresses undeliverable on transient API failures)**:
```typescript
const result = await verifyAddress(...);
await updateDeliverabilityStatus(addressId, result.deliverable ? "verified" : "undeliverable");
```

**Right**:
```typescript
const result = await verifyAddress(...);
if (result.valid === true) {
  const status = mapVerificationToDeliverabilityStatus(result);
  await updateDeliverabilityStatus(addressId, status, new Date());
}
// If result.valid is false, leave status alone.
// Use explicit markUndeliverable() for hard failures.
```

A failed Lob call (timeout, rate limit, bad data) is NOT evidence the address is undeliverable. Only an affirmative valid response gives us trustworthy data.

---

## 5. `updateContactPostal` must enforce primary-promotion constraints

**Wrong**: The `set-primary` endpoint enforces "no terminal status" and "no overriding worker_self," but the generic `update` endpoint silently allows `isPrimary: true` to bypass those checks via PUT.

**Right**: When `update` sees `isPrimary: true` and the address is currently non-primary, run the same gate:

1. Reject if target has terminal `deliverability_status`.
2. Reject if current primary is `worker_self` and target is not.
3. Then demote current primary and promote.

The reference code has this gate in `updateContactPostal` (see lines 279-294). Don't duplicate the logic — extract a helper if your codebase prefers, but ensure both paths gate identically.

---

## 6. Immutable fields are handled differently at the route and storage layers — by design

**Defense in depth, but with different behaviors**:

- **Route layer**: silently **strips** `source`, `street`, `city`, `state`, `postalCode`, `country` from `req.body` before parsing. Public API clients sending those fields get a 200 no-op, not a 400. This is intentional — it makes the API tolerant of stale frontend code that sends extra fields.
- **Storage layer**: in `updateContactPostal`, **throws** an explicit error if any immutable field reaches it. This protects against internal callers (cron jobs, importers, scripts) that bypass the route stripping.

If only the route strips them, internal callers can bypass. If only the storage layer rejects, the API returns confusing errors when stale frontend code submits stale fields. Both layers are needed and they have different observable behaviors — that's intentional, not a bug.

---

## 7. CHECK constraints must be added with idempotent existence checks

The migration adds CHECK constraints. If you re-run the migration (because someone restored a partial backup, or the migration tracking table was wiped), naive `ALTER TABLE ADD CONSTRAINT` fails because the constraint already exists.

**Right**: query `information_schema.table_constraints` first:

```typescript
const exists = await client.query(
  `SELECT 1 FROM information_schema.table_constraints
   WHERE table_name = 'contact_postal' AND constraint_name = $1`,
  [constraint.name]
);
if (exists.rowCount === 0) {
  await client.query(constraint.sql);
}
```

Same pattern for `ADD COLUMN` — query `information_schema.columns` first. The reference TypeScript migration shows the exact pattern.

**Don't swallow errors with `try { ... } catch { /* ignore */ }`**. That hides real bugs (typos in constraint SQL, permissions issues). Use existence checks instead.

---

## 8. Auto-promotion uses different selection rules in the delete path vs the markUndeliverable path

This is the most subtle inconsistency in the reference implementation. **Both behaviors are intentional and must be preserved on port** so existing data and tests continue to behave the same.

**Delete path (`deleteContactPostal`)** — source priority THEN recency:
```typescript
const deliverable = active.filter(a => !terminal(a));
const workerSelf = deliverable.find(a => a.source === "worker_self");
const nextBest = workerSelf || deliverable.sort(byRecency)[0];
```

**markUndeliverable path** — recency ONLY (no source priority):
```typescript
const allAddresses = await client.select().from(contactPostal)
  .where(eq(contactPostal.contactId, contactId))
  .orderBy(desc(contactPostal.updatedAt));
const nextBest = allAddresses.find(a =>
  a.id !== addressId && a.isActive && !terminal(a)
);
```

The historical reason: the delete path was implemented after the markUndeliverable path and added the worker_self priority improvement; the markUndeliverable path was never updated to match. Both paths are tested and depended upon.

A future refactor could unify these into a shared helper. Until then, **preserve the difference exactly** — and document it in any port. The acceptance tests D3 and D5 cover both paths.

---

## 9. Soft delete vs hard delete

The DELETE endpoint **does not delete**. It sets `is_active = false` and triggers primary promotion. This is intentional:

- Mail returned-to-sender investigations need to know an address existed
- Audit trails for benefit-eligibility disputes need history
- Deduplication needs to NOT match against inactive rows but should preserve them for query

Some teams instinctively want a true delete option for "data hygiene." Resist this. The `is_active = false` flag is sufficient. If a real privacy/GDPR delete is needed, that's a separate, gated operation, not the default.

---

## 10. The match algorithm normalization is intentionally lenient

Stripping `.` and `,` and `#`, lowercasing, collapsing whitespace, and taking the first 5 of the zip is intentional. Real-world data has:

- `"123 Main St."` vs `"123 main st"` vs `"123 Main Street"` (note: street/Street isn't normalized — accept the duplicate, it's better than aggressive normalization losing real differences)
- `"62701"` vs `"62701-1234"` (zip+4)
- `"Apt #5"` vs `"Apt 5"`

The current normalization handles the easy wins. Don't over-engineer it (e.g. don't try to normalize `"St"` ↔ `"Street"`) — that's a USPS-grade normalization problem and will cause false matches.

---

## 11. Frontend uses two POST routes deliberately

In a system without a worker portal yet, the frontend AddressManagement component uses only the admin route (`POST /api/contacts/:id/addresses`). The `POST /addresses/self` route exists for future worker-portal use.

This split is correct: it preserves the source-derivation security boundary so that when a worker portal is added later, it doesn't accidentally inherit admin privileges. Don't merge the routes. Don't make the frontend call `/self` for the admin UI.

---

## 12. The `validation_response` jsonb is for audit, not business logic

`validationResponse` stores the raw provider response (Lob, Google) for audit and debugging. It is NEVER queried for business decisions. All business decisions go through `deliverability_status` (canonical) or `deliverability_analysis` fields exposed by the verification service.

If you find yourself writing `WHERE validation_response @> ...`, stop. That's a sign you should add a first-class column or canonical mapping.

---

## 13. Lob "test mode" returns weird responses

Lob's API has a test mode (API keys prefixed `test_`) that returns simplified responses. Real addresses sent in test mode often return empty `components` because Lob only fully verifies a hardcoded list of test addresses.

The reference Lob provider has explicit handling for test mode — see lines 256-298 in `reference-code/server/services/providers/postal/lob.ts`. When porting, preserve this fallback or your dev-environment opt-in flow will mysteriously fail.

---

## 14. Don't over-think `needs_review` — it's a flag, not a workflow

`needs_review = true` is a boolean signal for staff to look at the address. There is no separate "review queue" table, no approval workflow, no notification system in the original. Staff sees the flag, investigates, and either:
- Promotes the flagged address to primary (clearing the flag implicitly)
- Marks it inactive
- Leaves it as a non-primary alternate

If the target codebase wants to build a review queue on top, that's fine — but the address feature itself only sets/reads the flag. Keep it simple.
