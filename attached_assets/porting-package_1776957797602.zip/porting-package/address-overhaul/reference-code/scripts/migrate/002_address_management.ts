import { registerMigration, type Migration } from "../../server/services/migration-runner";
import { logger } from "../../server/logger";
import { pool } from "../../server/db";

async function up(): Promise<void> {
  const client = await pool.connect();
  try {
    const columns = [
      { name: "source", definition: "text NOT NULL DEFAULT 'admin'" },
      { name: "deliverability_status", definition: "text NOT NULL DEFAULT 'unknown'" },
      { name: "last_verified_at", definition: "timestamp" },
      { name: "updated_at", definition: "timestamp NOT NULL DEFAULT now()" },
      { name: "needs_review", definition: "boolean NOT NULL DEFAULT false" },
    ];

    for (const col of columns) {
      const exists = await client.query(
        `SELECT 1 FROM information_schema.columns WHERE table_name = 'contact_postal' AND column_name = $1`,
        [col.name]
      );
      if (exists.rowCount === 0) {
        await client.query(`ALTER TABLE contact_postal ADD COLUMN ${col.name} ${col.definition}`);
        logger.info(`Added column ${col.name} to contact_postal`, { service: "migration-002" });
      }
    }

    const constraints = [
      {
        name: "chk_source",
        sql: `ALTER TABLE contact_postal ADD CONSTRAINT chk_source CHECK (source IN ('worker_self', 'employer_feed', 'admin', 'import', 'system'))`,
      },
      {
        name: "chk_deliverability_status",
        sql: `ALTER TABLE contact_postal ADD CONSTRAINT chk_deliverability_status CHECK (deliverability_status IN ('unknown', 'verified', 'undeliverable', 'vacant', 'returned_mail'))`,
      },
    ];

    for (const constraint of constraints) {
      const exists = await client.query(
        `SELECT 1 FROM information_schema.table_constraints WHERE table_name = 'contact_postal' AND constraint_name = $1`,
        [constraint.name]
      );
      if (exists.rowCount === 0) {
        await client.query(constraint.sql);
        logger.info(`Added constraint ${constraint.name} to contact_postal`, { service: "migration-002" });
      }
    }

    logger.info("Address management migration completed", { service: "migration-002" });
  } finally {
    client.release();
  }
}

const migration: Migration = {
  version: 2,
  name: "address_management",
  description: "Add source, deliverability_status, last_verified_at, updated_at, needs_review columns and check constraints to contact_postal",
  up,
};

registerMigration(migration);

export default migration;
