# Address Overhaul — Requirements & Business Rules

This document specifies the invariants the implementation must enforce. Any port that violates these is incorrect, regardless of how well it compiles.

## Schema invariants

The `contact_postal` table must include these columns (adapt names to host conventions if necessary, but field semantics must match):

| Column                  | Type        | Constraint                                                                  | Notes                                      |
| ----------------------- | ----------- | --------------------------------------------------------------------------- | ------------------------------------------ |
| `id`                    | UUID/string | PRIMARY KEY                                                                 |                                            |
| `contact_id`            | FK          | NOT NULL, ON DELETE CASCADE                                                 |                                            |
| `friendly_name`         | text        | nullable                                                                    | User-facing label (e.g. "Home", "Work")    |
| `street`                | text        | NOT NULL                                                                    | **Immutable after insert**                 |
| `city`                  | text        | NOT NULL                                                                    | **Immutable after insert**                 |
| `state`                 | text        | NOT NULL                                                                    | **Immutable after insert**                 |
| `postal_code`           | text        | NOT NULL                                                                    | **Immutable after insert**                 |
| `country`               | text        | NOT NULL                                                                    | **Immutable after insert**                 |
| `is_primary`            | bool        | NOT NULL, default false                                                     |                                            |
| `is_active`             | bool        | NOT NULL, default true                                                      | Soft-delete flag                           |
| `source`                | text        | NOT NULL, default `'admin'`, CHECK constraint                               | One of the enum values below               |
| `deliverability_status` | text        | NOT NULL, default `'unknown'`, CHECK constraint                             | One of the enum values below               |
| `last_verified_at`      | timestamp   | nullable                                                                    | Set when verification runs                 |
| `updated_at`            | timestamp   | NOT NULL, default now()                                                     | Bumped on every modification               |
| `needs_review`          | bool        | NOT NULL, default false                                                     | Set by employer_feed conflicts             |
| `validation_response`   | jsonb       | nullable                                                                    | Raw response from validation provider      |
| `latitude`              | float       | nullable                                                                    | From geocoding                             |
| `longitude`             | float       | nullable                                                                    |                                            |
| `accuracy`              | text        | nullable                                                                    | E.g. ROOFTOP, RANGE_INTERPOLATED           |
| `created_at`            | timestamp   | NOT NULL, default now()                                                     |                                            |

### Enum values (enforced via CHECK constraints in DB)

- `source` ∈ `{'worker_self', 'employer_feed', 'admin', 'import', 'system'}`
- `deliverability_status` ∈ `{'unknown', 'verified', 'undeliverable', 'vacant', 'returned_mail'}`

The CHECK constraints are required at the database level, not just in application code. Application-level enums leak when bulk imports or scripts bypass the validator.

## Append-only / immutability

The fields `street`, `city`, `state`, `postal_code`, `country` (and `source`) are **immutable** after creation. The implementation enforces this in two layers (defense in depth):

1. **Route layer**: silently strips `source`, `street`, `city`, `state`, `postal_code`, `country` from the request body before validation/parsing. This makes the public API tolerant of stale frontend code that sends extra fields — those fields are simply ignored.
2. **Storage layer**: in `updateContactPostal`, if any immutable field is present in the update payload, throws an explicit error: `"Address fields are immutable and cannot be changed: <fields>. Create a new address record instead."` This protects against internal callers (cron jobs, importers, scripts) that bypass the route stripping.

The net result for API clients: calling `PUT /api/addresses/:id` with `{ "street": "456 New St" }` succeeds with a no-op (200 response, address unchanged) because the route strips before storage sees it. Internal callers that bypass the route receive the explicit error.

Permitted update fields: `friendly_name`, `is_primary`, `is_active`, `latitude`, `longitude`, `accuracy`, `validation_response`, `needs_review`, `deliverability_status`, `last_verified_at`.

## Source semantics

`source` is **server-derived**. The client never sets it. Each route fixes the source based on its semantic meaning:

- The admin create route → `source: "admin"`
- The worker self-service route → `source: "worker_self"`
- The employer feed importer → `source: "employer_feed"`
- Bulk import scripts → `source: "import"`
- System-generated rows → `source: "system"`

When the create-or-match path finds an existing matching address, `source` is **NOT overwritten**, with one exception:

> **The worker_self exception**: If the new request has `source: "worker_self"` and matches an existing row, the row's `source` is stamped to `worker_self` (an upgrade) and the row is promoted to primary if it isn't already. This represents the worker affirming ownership of an address that may have originally come from another source.

For all other sources, a match found means only `updated_at` is bumped — the original source attribution is preserved.

## Deliverability semantics

- `unknown` is the default for any row that hasn't been verified.
- `verified` is set only after a successful verification call where `result.valid === true`. Do not write `verified` based on partial or fallback responses.
- `undeliverable`, `vacant`, `returned_mail` are **terminal**. Once an address enters one of these states, it should not be downgraded back to `unknown` or `verified` without an explicit re-verification cycle.
- A terminal-status address **cannot be primary**. The setter must reject this and the auto-promotion logic must respect it.

## Primary adjudication rules

At most one row per `contact_id` may have `is_primary = true` at any moment.

### On new address creation (no match found)

| Condition                                                                | Result                                  |
| ------------------------------------------------------------------------ | --------------------------------------- |
| No existing primary                                                      | New row becomes primary                 |
| New source is `worker_self`                                              | New row becomes primary (displaces old) |
| Existing primary has terminal `deliverability_status`                    | New row becomes primary                 |
| New source is `admin` AND existing primary is NOT `worker_self`          | New row becomes primary                 |
| New source is `admin` AND existing primary IS `worker_self`              | New row is non-primary, `needs_review = true` |
| New source is `employer_feed` AND deliverable primary exists             | New row is non-primary, `needs_review = true` |
| New source is `import` or `system`                                       | New row is non-primary                  |

### On match (existing active row found)

| Condition                          | Result                                                                  |
| ---------------------------------- | ----------------------------------------------------------------------- |
| New source is `worker_self`        | Stamp existing row's source to `worker_self`, promote to primary if not |
| Any other source                   | Bump `updated_at` only; do NOT overwrite source                         |

### On manual `setAddressAsPrimary`

- Reject if target row has terminal `deliverability_status`.
- Reject if the current primary has `source = worker_self` and the target does not.
- Otherwise, demote current primary and promote target (within a transaction).

### On `markUndeliverable` of the primary

- Set the row's `deliverability_status` to `undeliverable` (if not already in another terminal status — terminal statuses are preserved, not downgraded).
- Demote it (`is_primary = false`).
- Auto-promote the next best deliverable active address. "Next best" here = **most recently updated active address with non-terminal `deliverability_status`** (recency only — source priority is NOT applied in this path).
- If no candidate exists, the contact has no primary until a new address is added.

### On soft-delete (deactivation) of the primary

- Set `is_active = false`, `is_primary = false`.
- Auto-promote the next best deliverable active address. "Next best" here uses **source priority first** (`worker_self` wins) **then recency**. This differs intentionally from the `markUndeliverable` path because the delete path runs through a different storage helper.
- If no candidate exists, the contact has no primary until a new address is added.

> **Note**: The two auto-promotion paths use slightly different selection logic in the reference implementation (delete = worker_self-first then recency; markUndeliverable = recency-only). A future refactor could unify them; until then, the reference behavior should be preserved exactly so existing data and tests continue to behave the same.

## `needs_review` semantics

The `needs_review` flag signals that staff should investigate a conflict:

- Set when an `employer_feed` address arrives but a deliverable primary already exists.
- Set when an `admin` address arrives but the existing primary is `worker_self`.
- Cleared by staff via the metadata edit path (no explicit "clear review" action — staff just toggles primary or accepts the existing primary).

## Match-on-create algorithm

For deduplication, normalize and compare:

1. **Street**: trim → lowercase → collapse whitespace → strip `.`, `,`, `#`
2. **City**: same as street
3. **State**: same as street
4. **Postal code**: strip non-digits, take first 5 characters
5. **Active filter**: only match against rows where `is_active = true`

A match is a row where all four normalized fields match exactly.

## Validation flow integration

Address verification (Lob, Google, etc.) is decoupled from address creation:

1. Address rows can be created without verification (they get `deliverability_status: "unknown"`).
2. Verification can happen later (manually triggered or via batch jobs).
3. Verification updates `deliverability_status` ONLY if `result.valid === true`. A failed verification does NOT silently mark an address as undeliverable — that requires explicit `markUndeliverable` call.
4. When verification returns deliverability info, it maps to status via canonical helper functions (see `mapVerificationToDeliverabilityStatus` in the reference).
5. **Side effect**: when verification produces a terminal status (`undeliverable`, `vacant`, `returned_mail`) for an existing address row, the verification handler invokes `markUndeliverable` on that row. This means a single verify call can demote a primary and auto-promote a different address. Frontends should refetch the contact's address list after a verification call.
