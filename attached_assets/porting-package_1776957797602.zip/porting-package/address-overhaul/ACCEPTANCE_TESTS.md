# Address Overhaul — Acceptance Tests

These are **behavioral scenarios** the rebuild must pass. Each describes preconditions, action, and expected outcome. Implement them as integration tests where practical, or run them manually as verification.

---

## A. Source attribution

### A1 — Admin route forces `source = "admin"`

- **Setup**: empty contact
- **Action**: POST `/api/contacts/:id/addresses` with body `{ ..., source: "worker_self" }` (attempting to spoof)
- **Expected**: created address has `source = "admin"`. The client-supplied source is ignored.

### A2 — Worker self-service route forces `source = "worker_self"`

- **Setup**: empty contact
- **Action**: POST `/api/contacts/:id/addresses/self` with body `{ ..., source: "admin" }` (attempting to spoof)
- **Expected**: created address has `source = "worker_self"`.

### A3 — Source is preserved on match (non-worker_self)

- **Setup**: contact has an active address with `source = "admin"`
- **Action**: employer feed importer calls `createOrMatchAddress` with same address and `source = "employer_feed"`
- **Expected**: existing row is reused, source remains `"admin"`. Only `updated_at` is bumped.

### A4 — Source is upgraded on match when worker_self

- **Setup**: contact has an active address with `source = "admin"` and `is_primary = false`. Another address is currently primary.
- **Action**: POST `/api/contacts/:id/addresses/self` with the same street/city/state/zip
- **Expected**: existing matching row's source is updated to `"worker_self"`. The previous primary is demoted. The matching row becomes primary.

---

## B. Primary adjudication

### B1 — Worker self-reported address always becomes primary

- **Setup**: contact has an existing primary with `source = "admin"` and a deliverable status
- **Action**: POST `/api/contacts/:id/addresses/self` with a NEW address
- **Expected**: new address is primary. Previous primary is demoted to `is_primary = false`.

### B2 — Admin address replaces non-worker_self primary

- **Setup**: contact has an existing primary with `source = "employer_feed"`
- **Action**: POST `/api/contacts/:id/addresses` (admin route) with a NEW address
- **Expected**: new address becomes primary; previous demoted.

### B3 — Admin address does NOT replace worker_self primary

- **Setup**: contact has an existing primary with `source = "worker_self"`, deliverable
- **Action**: POST `/api/contacts/:id/addresses` (admin route) with a NEW address
- **Expected**: new address is created with `is_primary = false` and `needs_review = true`. Worker_self primary is unchanged.

### B4 — Employer feed never displaces deliverable primary

- **Setup**: contact has an existing primary (any source) with deliverable status
- **Action**: employer feed importer adds a NEW address with `source = "employer_feed"`
- **Expected**: new address is created with `is_primary = false` and `needs_review = true`.

### B5 — New address becomes primary if existing primary is terminal

- **Setup**: contact has an existing primary with `deliverability_status = "undeliverable"`
- **Action**: any source creates a NEW address
- **Expected**: new address becomes primary; old undeliverable address is demoted (cannot be primary anyway).

### B6 — `setAddressAsPrimary` rejects terminal address

- **Setup**: contact has an active address with `deliverability_status = "vacant"`
- **Action**: PUT `/api/addresses/:id/set-primary`
- **Expected**: 400 error: "Cannot set an undeliverable address as primary."

### B7 — `setAddressAsPrimary` rejects overriding worker_self with non-worker_self

- **Setup**: contact has primary with `source = "worker_self"` and another address with `source = "admin"`
- **Action**: PUT `/api/addresses/:adminAddressId/set-primary`
- **Expected**: 400 error: "Cannot override a worker-reported primary address. Only a worker_self address can replace it."

### B8 — At most one primary at all times

- **Setup**: contact has primary address A
- **Action**: any operation that promotes B to primary
- **Expected**: A becomes `is_primary = false` in the same transaction as B becomes `is_primary = true`. There is never a window where both are primary.

---

## C. Immutability

### C1 — PUT silently ignores immutable fields (route layer strips)

- **Setup**: existing address row with street `"123 Main St"`
- **Action**: PUT `/api/addresses/:id` with body `{ "street": "456 New St", "friendlyName": "Office" }`
- **Expected**: 200 response. Address still has street `"123 Main St"`, but `friendlyName` is now `"Office"`. The route silently strips immutable fields before validation.

### C1b — Storage layer rejects immutable fields (defense in depth)

- **Setup**: existing address row, calling `storage.contacts.addresses.updateContactPostal(id, {...})` directly (e.g. from a cron job or importer)
- **Action**: pass `{ street: "456 New St" }` to the storage function
- **Expected**: thrown error: `"Address fields are immutable and cannot be changed: street. Create a new address record instead."`

### C2 — Can change metadata fields

- **Setup**: existing address row
- **Action**: PUT `/api/addresses/:id` with body `{ "friendlyName": "Office", "isPrimary": true }`
- **Expected**: 200, address updated. `updated_at` is bumped.

### C3 — Database CHECK constraint blocks invalid source

- **Setup**: any address row
- **Action**: raw SQL `UPDATE contact_postal SET source = 'invalid_source' WHERE id = ...`
- **Expected**: database error from CHECK constraint. (This protects against bulk import scripts that bypass the application validator.)

### C4 — Database CHECK constraint blocks invalid deliverability_status

- Same shape as C3 but for `deliverability_status`.

---

## D. Soft delete and primary promotion

### D1 — Deactivate non-primary address

- **Setup**: contact with addresses A (primary) and B (non-primary, deliverable)
- **Action**: DELETE `/api/addresses/:bId`
- **Expected**: B has `is_active = false`. A remains primary.

### D2 — Deactivate primary triggers auto-promotion

- **Setup**: contact with addresses A (primary, admin), B (deliverable, admin), C (deliverable, admin)
- **Action**: DELETE `/api/addresses/:aId`
- **Expected**: A is deactivated. The most recently updated of B/C is promoted to primary.

### D3 — Delete-path auto-promotion prefers worker_self

- **Setup**: contact with addresses A (primary, admin), B (deliverable, worker_self, older `updated_at`), C (deliverable, admin, newer `updated_at`)
- **Action**: DELETE `/api/addresses/:aId`
- **Expected**: B is promoted to primary, even though C is more recent. In the **delete** path, worker_self wins over recency.

### D4 — Auto-promotion skips terminal-status addresses

- **Setup**: contact with addresses A (primary), B (`deliverability_status = "undeliverable"`)
- **Action**: DELETE `/api/addresses/:aId`
- **Expected**: A is deactivated. B is NOT promoted (terminal). Contact has no primary until a new address is added.

### D5 — `markUndeliverable` of primary auto-promotes by recency only

- **Setup**: contact with addresses A (primary, deliverable), B (deliverable, worker_self, older `updated_at`), C (deliverable, admin, newer `updated_at`)
- **Action**: PUT `/api/addresses/:aId/mark-undeliverable`
- **Expected**: A is `deliverabilityStatus = "undeliverable"`, `is_primary = false`. **C** is promoted to primary because the markUndeliverable path uses recency only (it does NOT apply the worker_self priority that the delete path applies). This is intentional reference behavior; see REQUIREMENTS for the rationale.

### D5b — `markUndeliverable` with single deliverable alternate

- **Setup**: contact with addresses A (primary, deliverable), B (deliverable)
- **Action**: PUT `/api/addresses/:aId/mark-undeliverable`
- **Expected**: A is undeliverable and demoted; B is promoted to primary.

### D6 — `markUndeliverable` of already-terminal address preserves status

- **Setup**: address A has `deliverability_status = "vacant"`
- **Action**: PUT `/api/addresses/:aId/mark-undeliverable`
- **Expected**: A's `deliverability_status` remains `"vacant"` (don't downgrade `vacant` → `undeliverable`). `updated_at` is bumped.

---

## E. Match deduplication

### E1 — Matches by normalized fields

- **Setup**: contact has active address `"123 Main St, Springfield, IL, 62701"`
- **Action**: any source creates `"123 main st., Springfield, IL, 62701-1234"`
- **Expected**: existing row is reused (normalization strips `.`, lowercases, takes first 5 of zip). Returns 200 (not 201).

### E2 — Does NOT match against inactive rows

- **Setup**: contact has an INACTIVE row matching the address
- **Action**: create a new address with the same fields
- **Expected**: a new active row is created (201). The inactive row is left alone.

### E3 — Matches scoped to contact

- **Setup**: contact A has address X. Contact B does not.
- **Action**: create address X for contact B
- **Expected**: a new row is created for contact B (no cross-contact deduplication).

---

## F. Verification integration

### F1 — Verification updates status only on `valid === true`

- **Setup**: address with `deliverability_status = "unknown"`
- **Action**: POST `/api/postal/verify-address` returns `{ valid: false, deliverable: false, ... }`
- **Expected**: address row's `deliverability_status` remains `"unknown"`. (Failed verification is not a death sentence — that requires explicit `markUndeliverable`.)

### F2 — Verification updates status on success

- **Setup**: address with `deliverability_status = "unknown"`
- **Action**: POST `/api/postal/verify-address` with `addressId`, response is `{ valid: true, deliverable: true, deliverabilityAnalysis: { dpvMatchCode: "Y", dpvVacant: "N", ... } }`
- **Expected**: address row updated to `deliverability_status = "verified"`, `last_verified_at` set.

### F2b — Verification with terminal result invokes markUndeliverable side effect

- **Setup**: address A (primary, deliverable), address B (deliverable, non-primary) for same contact
- **Action**: POST `/api/postal/verify-address` for A returns `{ valid: true, deliverabilityAnalysis: { dpvVacant: "Y" } }` → maps to terminal `vacant`
- **Expected**: A's status becomes `vacant`, A is demoted, B is auto-promoted to primary. (The verify handler calls `markUndeliverable` internally when a terminal status is produced, so the full primary-promotion side effects fire.)

### F3 — Lob DPV vacant flag maps to `vacant`

- **Action**: verification returns `{ valid: true, deliverabilityAnalysis: { dpvVacant: "Y" } }`
- **Expected**: `deliverability_status = "vacant"`.

### F4 — Lob undeliverable maps to `undeliverable`

- **Action**: verification returns `{ valid: true, deliverable: false }` or appropriate Lob undeliverable response
- **Expected**: `deliverability_status = "undeliverable"`.

(See `mapVerificationToDeliverabilityStatus` in `reference-code/server/services/address-validation.ts` for the canonical mapping.)

---

## G. Listing and frontend display

### G1 — List orders primary first

- **Setup**: contact with addresses A (non-primary), B (primary), C (non-primary)
- **Action**: GET `/api/contacts/:id/addresses`
- **Expected**: response is ordered `[B, A, C]` (primary first, then by storage order).

### G2 — Frontend shows source badge for every address

- **Action**: render the address management component
- **Expected**: each card shows a badge for its source (`Worker`, `Employer`, `Admin`, `Import`, `System`).

### G3 — Frontend shows deliverability badge for non-unknown statuses

- **Action**: render the address management component
- **Expected**: addresses with status other than `unknown` show a colored badge with appropriate icon (verified=green check, undeliverable/vacant/returned_mail=red).

### G4 — `needsReview` addresses are visually flagged

- **Action**: render an address with `needs_review = true`
- **Expected**: the card shows a visual indicator (badge, color, icon) that staff attention is needed.
