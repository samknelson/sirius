# Address Overhaul — Append-Only Address Management

## What This Is

A redesign of postal-address handling for contact records that replaces traditional in-place editing with an **append-only** model. Addresses become immutable once created; metadata edits (label, primary status) are still allowed, but the actual address fields (street, city, state, postal code, country) are write-once.

## Why It Exists

In the previous in-place model, when a worker moved or an employer feed updated an address, the original was overwritten and history was lost. That hurt:

- **Mail returned-to-sender investigations** — staff couldn't tell whether mail was sent to a now-stale address or whether the address had simply changed
- **Source attribution** — there was no way to know whether an address came from the worker themselves, an employer payroll feed, an admin entry, or a bulk import
- **Deliverability tracking** — addresses verified as undeliverable could be silently re-marked as primary by a subsequent feed update
- **Audit / dispute resolution** — when a worker disputed where benefits were sent, history was unrecoverable

The append-only model preserves history, attributes every address to a source, tracks deliverability over time, and adjudicates which address is "primary" based on a clear priority hierarchy.

## Core Concepts

### Append-only

Once an address row is created, the physical fields (street, city, state, postalCode, country) are **immutable**. To "change" an address, you create a new row; the old row remains active and queryable (it is **not** automatically soft-deleted). Staff or workers may explicitly soft-delete the old row when they want it gone. All history remains queryable.

### Source attribution

Every address has a `source` field recording who reported it:

- `worker_self` — the worker entered or confirmed the address themselves (highest priority)
- `employer_feed` — came from an employer's payroll/HR data feed (always treated with suspicion; gets `needsReview`)
- `admin` — entered by staff via the admin UI
- `import` — came from a bulk import job (e.g. legacy data migration)
- `system` — created by automated processes

`source` is **server-derived**, never accepted from the client. The route the request comes through determines the source.

### Deliverability tracking

Every address has a `deliverabilityStatus`:

- `unknown` — never verified (the default)
- `verified` — confirmed deliverable by an external service (Lob, USPS)
- `undeliverable` — verification failed
- `vacant` — verified but no occupant (USPS DPV vacant flag)
- `returned_mail` — mail was physically returned

The last three are **terminal statuses**. An address with a terminal status cannot be primary.

### Primary adjudication

Each contact has at most one primary address at any time. When a new address arrives or a primary becomes terminal, the system applies these rules:

- A `worker_self` address always wins, even over an existing primary.
- An `admin` address becomes primary unless the existing primary is `worker_self`.
- An `employer_feed` address never displaces an existing deliverable primary; it gets `needsReview = true` so staff can investigate.
- When a primary becomes terminal, the system auto-promotes the next best deliverable address (preferring `worker_self`, then most recently updated).

### Soft delete

Addresses are never hard-deleted. "Delete" sets `isActive = false` and triggers primary promotion if needed. This preserves history.

### Match-on-create deduplication

When a new address request comes in, the system normalizes street/city/state/zip and looks for an existing active match. If found, the existing row is reused (updated only if the new source warrants it — see GOTCHAS for the worker_self exception).

## Host-Codebase Dependencies

This feature assumes the host project has:

1. A **contacts** table (generic person/entity record) with a primary key the address rows can reference
2. An **access policy / permission middleware** system (the reference uses `requireAccess('contact.edit', getContactId)`)
3. A **storage abstraction layer** for centralized DB access with audit logging (the reference uses `server/storage/`)
4. A **migration runner** for versioned schema migrations
5. A **postal provider abstraction** if external address verification is desired (the reference integrates Lob, but the address feature itself functions without it)
6. A **frontend stack** with React + a query client (TanStack Query in the reference) + shadcn/ui-style components

The address feature does **not** require the host to have any pre-existing address handling — it can be added cleanly to a contacts system that has none.
