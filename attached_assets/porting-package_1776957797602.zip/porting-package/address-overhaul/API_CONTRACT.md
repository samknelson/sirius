# Address Overhaul — API Contract

All endpoints require authentication. Authorization is controlled by an access-policy middleware in the source codebase (`requireAccess('contact.edit', getContactId)` etc.). The target codebase should map to its equivalent permission system.

---

## GET `/api/contacts/:contactId/addresses`

List all addresses for a contact, sorted with primary first.

**Auth**: `worker.view` if the contact belongs to a worker, `employer.manage` if it belongs to an employer contact, otherwise `staff`.

**Response 200**: Array of `ContactPostal` objects:

```json
[
  {
    "id": "uuid",
    "contactId": "uuid",
    "friendlyName": "Home",
    "street": "123 Main St",
    "city": "Springfield",
    "state": "IL",
    "postalCode": "62701",
    "country": "United States",
    "isPrimary": true,
    "isActive": true,
    "source": "worker_self",
    "deliverabilityStatus": "verified",
    "lastVerifiedAt": "2025-04-12T10:00:00Z",
    "updatedAt": "2025-04-12T10:00:00Z",
    "needsReview": false,
    "validationResponse": { "...": "..." },
    "latitude": 39.78,
    "longitude": -89.65,
    "accuracy": "ROOFTOP",
    "createdAt": "2025-04-10T08:00:00Z"
  }
]
```

---

## GET `/api/addresses/:id`

Get a single address by ID.

**Auth**: `contact.view` for the address's `contactId`.

**Response 200**: A `ContactPostal` object (see shape above).
**Response 404**: `{ "message": "Address not found" }`

---

## POST `/api/contacts/:contactId/addresses`

Admin path: create a new address (or match against an existing one) for the contact. Server forces `source = "admin"`.

**Auth**: `contact.edit` for `:contactId`.

**Request body**:

```json
{
  "street": "123 Main St",
  "city": "Springfield",
  "state": "IL",
  "postalCode": "62701",
  "country": "United States",
  "friendlyName": "Home",
  "validationResponse": { "geometry": { "location": {"lat": 39.78, "lng": -89.65}, "location_type": "ROOFTOP" } }
}
```

`source` in the request body is **ignored**. The route always sets `admin`.

**Response 201**: Created address (a `ContactPostal` object).
**Response 200**: Existing matched address (when an active duplicate was found).
**Response 400**: `{ "message": "<error>" }` for validation or business-rule failures.

---

## POST `/api/contacts/:contactId/addresses/self`

Worker self-service path: create or match an address with `source = "worker_self"`. The matched/created address always becomes primary (the worker's word is final).

**Auth**: `contact.edit` for `:contactId` (in a worker portal, this would be the worker's own contact).

**Request body**: Same as the admin route.

**Response 201/200**: Same as the admin route.

---

## PUT `/api/addresses/:id`

Update an existing address's metadata. Address fields (`street`, `city`, `state`, `postalCode`, `country`) **cannot** be changed.

**Auth**: `contact.edit` for the address's `contactId`.

**Request body** (all optional):

```json
{
  "friendlyName": "Office",
  "isPrimary": true,
  "validationResponse": { "...": "..." },
  "latitude": 39.78,
  "longitude": -89.65,
  "accuracy": "ROOFTOP"
}
```

The route silently strips `source`, `street`, `city`, `state`, `postalCode`, `country` from the body before processing. The storage layer additionally throws if those fields somehow reach it (defense-in-depth against internal callers that bypass the route). Public API clients therefore get a successful no-op response when they include immutable fields, not a 400.

**Response 200**: Updated address (or unchanged address if only immutable fields were sent — they are stripped silently).
**Response 400**: For other business-rule failures, e.g. attempting to set a terminal-status address as primary, or attempting to override a worker_self primary with a non-worker_self address: `{ "message": "Cannot set an undeliverable address as primary." }` etc.

---

## PUT `/api/addresses/:id/set-primary`

Promote an address to primary. Demotes the current primary in the same transaction.

**Auth**: `contact.edit` for the address's `contactId`.

**Request body**: Empty.

**Response 200**: Updated address (now primary).
**Response 400**:
- `"Cannot set an undeliverable address as primary."` — target has terminal deliverability_status
- `"Cannot override a worker-reported primary address. Only a worker_self address can replace it."` — current primary is `worker_self` and target is not

---

## PUT `/api/addresses/:id/mark-undeliverable`

Mark an address as undeliverable. If it was primary, auto-promote the next best deliverable address.

**Auth**: `contact.edit` for the address's `contactId`.

**Request body**: Empty.

**Response 200**: Updated address (now `deliverabilityStatus: "undeliverable"`, `isPrimary: false`).

If the address was already in a terminal state (e.g. `vacant`), the existing terminal status is preserved (don't downgrade `vacant` → `undeliverable`).

---

## DELETE `/api/addresses/:id`

Soft-delete (deactivate) an address. If it was primary, auto-promote the next best deliverable active address.

**Auth**: `contact.edit` for the address's `contactId`.

**Response 204**: No content.
**Response 404**: `{ "message": "Address not found" }`

---

## Postal Verification Integration

Address verification is exposed by the postal/comm module, not the address module. Relevant endpoints (kept here for completeness — these may already exist in the target codebase under a different name):

### POST `/api/postal/verify-address`

Run verification (Lob etc.) on an address. Updates the address's `deliverabilityStatus` and `lastVerifiedAt` if the address ID is provided.

**Request body**:

```json
{
  "addressId": "uuid",
  "addressLine1": "123 Main St",
  "city": "Springfield",
  "state": "IL",
  "zip": "62701",
  "country": "US"
}
```

**Response 200**:

```json
{
  "valid": true,
  "deliverable": true,
  "canonicalAddress": "123 MAIN ST, SPRINGFIELD, IL 62701",
  "normalizedAddress": { "...": "..." },
  "deliverabilityAnalysis": { "dpvMatchCode": "Y", "...": "..." }
}
```

The address row's `deliverability_status` is updated **only when `valid === true`**. A failed verification does NOT silently mark the address undeliverable.

**Side effect**: when verification produces a terminal status (`undeliverable`, `vacant`, `returned_mail`) for the address, the handler internally calls `markUndeliverable` on the row. That can demote a primary and auto-promote a different address. Frontends should refetch the contact's address list after this call.

---

## Source Attribution: Server-Derived Only

A non-negotiable rule: the API MUST NOT accept `source` from the client. Every route hard-codes the source:

| Endpoint                                    | Forced source     |
| ------------------------------------------- | ----------------- |
| POST `/api/contacts/:id/addresses`          | `admin`           |
| POST `/api/contacts/:id/addresses/self`     | `worker_self`     |
| (employer feed importer)                    | `employer_feed`   |
| (bulk import scripts)                       | `import`          |
| (system-generated)                          | `system`          |

If the client sends `source: "worker_self"` to the admin route, it is ignored. This prevents privilege escalation.

---

## Error Response Shape

All error responses follow this shape:

```json
{
  "message": "Human-readable description",
  "errors": { "...": "..." }   // optional, for Zod validation errors
}
```

HTTP status codes:

- `200` — success (existing matched, or update successful)
- `201` — created (new row inserted)
- `204` — success with no content (delete)
- `400` — validation or business-rule failure
- `404` — address or contact not found
- `500` — unexpected server error
