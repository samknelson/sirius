-- =============================================================================
-- Address Overhaul — Framework-Neutral SQL Schema
-- =============================================================================
-- This file contains the DDL needed to support the append-only address
-- management feature. It is provided in two forms:
--
--   1. FULL FINAL-STATE DDL — for fresh installs (`CREATE TABLE` from scratch)
--   2. MIGRATION DELTA — for an existing contact_postal table (`ALTER TABLE`)
--
-- Adapt to your target database (PostgreSQL syntax shown). For other databases,
-- the only non-standard pieces are: gen_random_uuid() (use your UUID default),
-- jsonb (use JSON or equivalent), and timestamp without time zone.
-- =============================================================================


-- =============================================================================
-- FORM 1: FULL FINAL-STATE DDL
-- Use this if your target project does not yet have a contact_postal table.
-- =============================================================================

CREATE TABLE contact_postal (
    id                     varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    contact_id             varchar NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
    friendly_name          text,
    street                 text NOT NULL,
    city                   text NOT NULL,
    state                  text NOT NULL,
    postal_code            text NOT NULL,
    country                text NOT NULL,
    is_primary             boolean NOT NULL DEFAULT false,
    is_active              boolean NOT NULL DEFAULT true,
    source                 text NOT NULL DEFAULT 'admin',
    deliverability_status  text NOT NULL DEFAULT 'unknown',
    last_verified_at       timestamp,
    updated_at             timestamp NOT NULL DEFAULT now(),
    needs_review           boolean NOT NULL DEFAULT false,
    validation_response    jsonb,
    latitude               double precision,
    longitude              double precision,
    accuracy               text,
    created_at             timestamp NOT NULL DEFAULT now(),

    CONSTRAINT chk_source CHECK (
        source IN ('worker_self', 'employer_feed', 'admin', 'import', 'system')
    ),
    CONSTRAINT chk_deliverability_status CHECK (
        deliverability_status IN ('unknown', 'verified', 'undeliverable', 'vacant', 'returned_mail')
    )
);

-- Helpful indexes for common access patterns
CREATE INDEX idx_contact_postal_contact_id ON contact_postal(contact_id);
CREATE INDEX idx_contact_postal_contact_primary
    ON contact_postal(contact_id, is_primary)
    WHERE is_active = true;
CREATE INDEX idx_contact_postal_needs_review
    ON contact_postal(needs_review)
    WHERE needs_review = true;


-- =============================================================================
-- FORM 2: MIGRATION DELTA
-- Use this if your target project already has a contact_postal table with the
-- pre-overhaul shape (street/city/state/postal_code/country/is_primary/is_active
-- but no source/deliverability_status/etc.).
--
-- Wrap each ADD COLUMN and ADD CONSTRAINT in an existence check (e.g.
-- information_schema.columns / information_schema.table_constraints) so the
-- migration is idempotent. The reference TypeScript migration in
-- reference-code/scripts/migrate/002_address_management.ts shows the pattern.
-- =============================================================================

-- Add new columns
ALTER TABLE contact_postal
    ADD COLUMN source                 text NOT NULL DEFAULT 'admin';

ALTER TABLE contact_postal
    ADD COLUMN deliverability_status  text NOT NULL DEFAULT 'unknown';

ALTER TABLE contact_postal
    ADD COLUMN last_verified_at       timestamp;

ALTER TABLE contact_postal
    ADD COLUMN updated_at             timestamp NOT NULL DEFAULT now();

ALTER TABLE contact_postal
    ADD COLUMN needs_review           boolean NOT NULL DEFAULT false;

-- Add CHECK constraints (REQUIRED — application-level enums leak via bulk imports)
ALTER TABLE contact_postal
    ADD CONSTRAINT chk_source CHECK (
        source IN ('worker_self', 'employer_feed', 'admin', 'import', 'system')
    );

ALTER TABLE contact_postal
    ADD CONSTRAINT chk_deliverability_status CHECK (
        deliverability_status IN ('unknown', 'verified', 'undeliverable', 'vacant', 'returned_mail')
    );

-- Add helpful indexes
CREATE INDEX IF NOT EXISTS idx_contact_postal_contact_primary
    ON contact_postal(contact_id, is_primary)
    WHERE is_active = true;

CREATE INDEX IF NOT EXISTS idx_contact_postal_needs_review
    ON contact_postal(needs_review)
    WHERE needs_review = true;


-- =============================================================================
-- NOTES
-- =============================================================================
-- 1. The `contacts` table is assumed to exist with a varchar/UUID `id` primary
--    key. Adapt the FK type if your contacts table uses serial/integer IDs.
--
-- 2. `gen_random_uuid()` is PostgreSQL's pgcrypto/random UUID generator. On
--    PostgreSQL 13+ it is built-in. Otherwise enable pgcrypto:
--        CREATE EXTENSION IF NOT EXISTS pgcrypto;
--
-- 3. The CHECK constraints are deliberately strict. If your target needs to
--    add new source or deliverability values later, add them to BOTH the
--    application enum AND the CHECK constraint via a coordinated migration.
--
-- 4. `validation_response` is jsonb to store the raw provider response (Lob,
--    Google, etc.) for audit and debugging. It is not used by business logic.
-- =============================================================================
