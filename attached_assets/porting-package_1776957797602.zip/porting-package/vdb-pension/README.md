# GBHE VDB Pension — Variable Defined Benefit Pension Administration

## What This Is

The VDB ("Variable Defined Benefit") pension feature administers a multi-employer defined-benefit pension fund for the GBHE site. It tracks worker pension accruals, converts annual contributions into VDB shares whose unit value floats, runs the actuarial math used to project retirement benefits across all election types, and exposes admin tooling for managing benefit schedules, accrual tiers, plan-year configurations, share values, and actuarial factor tables (AI factors, payout factors, early-retirement factors, lump-sum interest rates).

It is a **site-specific** plugin: gated behind the `sitespecific.gbhet.pension` component flag, with its own admin pages under `/sitespecific/gbhet/pension/...` and a worker-facing summary at `/workers/:id/vdb-pension`.

## Why It Exists

GBHE administers a hybrid pension whose accrual rules changed mid-life:

- **Pre-2019 plan years** — accruals were determined by an hourly schedule. Each year a worker's annual hours were bucketed into a tier (e.g. "≥1,200 hours = 100% of monthly benefit rate, ≥800 hours = 50%, …"). The matching tier's percentage multiplied a per-year, per-plan ("Plan A" vs "Plan B") monthly benefit rate to produce that year's annual accrual (an SLA — "Stated Life Annuity" — dollar amount).
- **2019+ plan years** — the fund switched to a contribution-percentage model. A configurable percent of each worker's hourly charges is booked as a pension contribution; that contribution is then converted into VDB shares by dividing by the start-of-year share value. Workers with a "special designation" member status can have a different (typically higher) contribution percent.

Both accrual streams persist for any given worker. At retirement, the calculator must:

1. Aggregate the pre-2019 SLA dollars (annuity floor) and the 2019+ shares (variable benefit at current share value).
2. Apply the **70.5 actuarial increase (AI)** for workers who keep working past their Mandatory Retirement Date (MRD = April 1 of the year after they turn 70½).
3. Apply a separate **DoT-to-DoBC AI** when the Date of Termination is before the Date of Benefit Commencement and DoBC is past age 65.
4. Pick the greater of (a) the AI-grossed annuity dollars and (b) the AI-grossed shares × current share value.
5. Look up the right payout factor for the chosen election type (Life Annuity, 5-Year Certain & Continuous, 50/75/100% Joint & Survivor, Lump Sum, Lump Sum Early), apply early-retirement reduction if applicable, and project the monthly or lump payout.
6. For tiny lump sums (monthly Life Annuity ≤ $100), additionally compute interest from DoBC to the actual payment date.

A purpose-built VDB Payout Calculator surfaces all of this for staff so they can answer "what would this worker get if …" questions in one screen.

## Core Concepts

### Dual accrual model (driven by `gbhet_pension_plan_years.accrualMethod`)

- `tiered` — pre-2019 style. Looks up the worker's annual hours, finds the matching tier, multiplies tier % by the year+plan benefit rate, books an SLA dollar entry to the SLA ledger account.
- `contribution_pct` — 2019+ style. The plan year stores a `contributionPct` (and optional `specialDesignationContributionPct`). When an entry hits the configured "trigger" account (typically the hourly-charge account), the SLA Contribution plugin creates a derived SLA-dollar entry on the SLA account; the Variable Contribution plugin then converts that SLA-dollar into shares using the start-of-year share value and books the shares to the share-target account.

The accrual method is **never hard-coded by year** — it is read from the plan-year row. Importing a new plan year row changes behaviour for that year.

### The three-plugin chain (charge plugins)

1. `gbhe-hourly-charge` — fires on `HOURS_SAVED`. Charges an employer (or worker) a per-hour rate from a configurable rate-history table. Special-designation workers (identified by member-status IDs) get a fixed monthly hours pattern (default 135). This plugin emits ledger entries on the hourly account, which becomes the **trigger** for the next plugin in contribution_pct years.
2. `gbhet-pension-sla-contribution` — fires on `LEDGER_ENTRY_SAVED`, listening for entries on the configured trigger account in years whose plan-year accrual method is `contribution_pct`. Computes `slaAmount = triggerAmount × contributionPct`, attributes to the worker (resolving worker ID from entry data or hours reference), and books an SLA-dollar entry to the SLA output account.
3. `gbhet-pension-variable-contribution` — fires on `LEDGER_ENTRY_SAVED`, listening for entries created by the SLA Contribution plugin. Looks up the start-of-year share value for that entry's year, computes `shares = slaAmount / shareValue`, and books a shares entry to the variable-contribution target account.

All three plugins are **idempotent** via `chargePluginKey` lookups: re-running over the same source entries updates rather than duplicates.

### Shares vs SLA vs accumulated benefit

At any point a worker has:

- **Total shares** (sum of all variable-contribution entries) — converts to a dollar value at the current share value.
- **Total SLA** (sum of pre-2019 hourly accruals + 2019+ SLA contributions) — a dollar floor.
- **Variable benefit** = `totalShares × currentShareValue`.
- **Accumulated benefit** = `max(variableBenefit, totalSLA)` — i.e. the SLA acts as a floor under the variable benefit.

### Actuarial increases (AI)

Two separate AI calculations can apply, and they **compose**:

- **70.5 AI** — applies when the end of accrual (DoT if provided, else DoBC) is at or after MRD. AI is computed at MRD and at January 1 of each subsequent year up to the truncated end date, by interpolating the AI factor table monthly and computing `aiRatio = (prevFactor / currentFactor) − 1`. The earned AI is added to a running total separately for annuity and shares; the final accrued benefit picks the greater of annuity dollars or shares × payout share value.
- **DoT-to-DoBC AI** — applies when the worker terminated, then deferred their DoBC past their normal retirement age (default 65). Start = later of `(birthday at age 65, DoT)`. End = DoBC. One AI ratio is computed from the start-vs-end interpolated factors and applied. If 70.5 AI also applied, the DoT-to-DoBC AI consumes the post-70.5 accrued amounts as input.

The interpolated factor for an exact age `Y years M months` is `((factor[Y] × (12 − M)) + (factor[Y+1] × M)) / 12`.

### Election types and payout factors

Election types (encoded as 2-letter / short codes in the `payout_factors` table):

- `life` — Life Annuity (monthly)
- `5cc` — 5-Year Certain & Continuous (monthly)
- `50js` / `75js` / `100js` — Joint & Survivor at 50/75/100% (monthly; require beneficiary age)
- `lump` — Lump Sum (one-time payment; year-based factor lookup)
- `lumpearly` — Lump Sum (Early Retirement variant; year-based)

For monthly types: `monthlyBenefit = (accumulatedBenefit × payoutFactor × earlyRetirementAdjustment) / 12`.
For lump types: `lumpAmount = accumulatedBenefit × payoutFactor`.

Joint & Survivor lookups key on subscriber age × beneficiary age. Lump lookups key on subscriber age × `factorYear` (lets the table evolve over time without retroactively changing past quotes).

### Early retirement reduction

When the worker is below normal retirement age (default 65) and an `earlyRetirementReason` is given, look up the per-month reduction factor for that reason. `monthsEarly = months between DoBC and the 65th birthday (floored at 0)`. `adjustment = max(0, 1 − (monthsEarly × monthlyFactor))`. Applied multiplicatively to monthly election types only (never to lump sums).

### Lump-sum interest

If the **monthly Life Annuity benefit** is ≤ $100, lump-sum payouts qualify for cash-out. When a payment date is supplied that's after DoBC, interest accrues from DoBC to payment date at the DoBC year's annual interest rate, prorated monthly: `interest = lumpAmount × (annualRate / 12) × monthsBetween(dobc, paymentDate)`.

### Mandatory election

`mandatory` exists in the election-type enum to represent default mandatory cash-outs but is not a calculator output (the calculator emits Life/5cc/JS/Lump/LumpEarly only). Storage and validation accept it for record-keeping.

## Host-Codebase Dependencies

This feature assumes the host project has:

1. **Workers + Contacts** — a worker record with a `contactId` pointing to a contact carrying `firstName`, `lastName`, `birthDate` (the worker's date of birth is read from contact, not from the worker row). Workers must also expose a `denormHomeEmployerId` (used to pick Plan A vs B) and a `denormMsIds: string[]` of member-status IDs (used for special-designation detection).
2. **Employers** — referenced by employer-plan rows.
3. **Worker hours** — `storage.workerHours.getWorkerYearlyHoursTotal(workerId, year)` returning a number, plus `getWorkerHoursById` for resolving worker IDs from hour-reference ledger entries.
4. **Ledger system** — accounts, entity-account (EA) rows that bind an account to an `(entityType, entityId)` pair, and ledger entries with at least: `id`, `chargePlugin`, `chargePluginKey`, `chargePluginConfigId`, `amount`, `eaId`, `referenceType`, `referenceId`, `date`, `memo`, and a JSON `data` blob. Entries must support `getByChargePluginKey`, `getByEaId`, `getRawByAccountId`, `update`, `create`, `deleteByChargePluginKey`, and a `getBalance(eaId)` per-EA aggregator.
5. **Charge plugin framework** — base `ChargePlugin` class, registry, trigger types (`HOURS_SAVED`, `LEDGER_ENTRY_SAVED`), per-config settings (`ChargePluginConfig`) with global scope, and a verifier interface that returns expected vs. actual amounts/memos.
6. **Component flag system** — `requireComponent("sitespecific.gbhet.pension")` middleware that 503s if the feature isn't enabled in the target install.
7. **Variables / settings store** — `storage.variables.getByName/create/update` for storing the four configurable account IDs (SLA output, SLA trigger, variable-contribution source, variable-contribution target).
8. **Auth middleware** — `requireAuth` and `requirePermission(key)` (the reference uses `"admin"` for management endpoints and `"staff"` for read-only worker summaries).
9. **Frontend stack** — React + TanStack Query + Wouter + shadcn/ui + Tailwind. The reference UI uses CSV/TSV paste-and-import dialogs with a column-mapping wizard for payout factors.

The pension feature does **not** require any pre-existing pension or benefits handling — it can be added to a worker management system that has only hours and ledger.
