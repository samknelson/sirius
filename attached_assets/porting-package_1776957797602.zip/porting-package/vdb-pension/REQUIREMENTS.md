# VDB Pension — Functional & Computational Requirements

This document specifies what the feature must do. It does not prescribe how to structure the code in the target project; the reference implementation in `reference-code/` shows one working approach.

## R1. Plan Years (the source of truth for accrual behaviour)

R1.1 A `gbhet_pension_plan_years` table stores per-year configuration with one row per year. Each row carries:

- `year` (unique, integer)
- `accrualMethod` ∈ {`tiered`, `contribution_pct`}
- `contributionPct` (numeric, percent — only used in contribution_pct years; nullable)
- `specialDesignationContributionPct` (nullable; falls back to `contributionPct` when absent)
- `qualificationThresholdHours` (default 500)
- `specialDesignationMonthlyHours` (default 135)
- `shareValue` (the **start-of-year** share value for that plan year — used by the variable contribution plugin to convert SLA dollars into shares)
- `notes`, free-form `data` jsonb

R1.2 Adding or editing a plan year **immediately changes the rules** for that year on subsequent computations. There must be no hard-coded year cutoffs in the calculator or plugins.

R1.3 Admin CRUD for plan years must validate uniqueness on `year` and surface 409 conflicts cleanly. The accrual-method enum is the canonical `["tiered", "contribution_pct"]`.

## R2. Tiered Accrual (pre-2019 style)

R2.1 `gbhet_pension_accrual_tiers` rows store `(year, minHours, accrualPct)` with uniqueness on `(year, minHours)`. Multiple tiers per year allowed (e.g. minHours 0, 500, 800, 1200, …). The "effective" tier list for a year may be the year's own rows, or fall back to the most recent prior year's rows if none exist for the year — the reference's `getEffectiveTiersForYear` is permitted but not required.

R2.2 `gbhet_pension_benefit_schedules` rows store `(year, plan, monthlyBenefitRate)` with uniqueness on `(year, plan)`. Plan is `"A"` or `"B"`.

R2.3 `gbhet_pension_employer_plans` maps each employer to plan A or B (uniqueness on `employerId`). When a worker has no `denormHomeEmployerId` mapping, default to Plan A.

R2.4 Annual accrual computation for a `tiered` plan year:

1. Read `totalHours = workerHours.getWorkerYearlyHoursTotal(workerId, year)`.
2. Determine `qualified = totalHours >= planYear.qualificationThresholdHours` (default 500).
3. Sort tiers descending by `minHours`; pick the first tier where `totalHours >= tier.minHours`. If none, skip with reason "Hours below minimum tier threshold".
4. Resolve `plan` from the worker's home employer's plan assignment (default "A").
5. Look up `benefitSchedule = (year, plan)`. If missing, skip with reason.
6. `amount = benefitRate × (accrualPct / 100)` rounded to 2 decimals.
7. Memo: `"SLA {year}: {totalHours} hrs → {accrualPct}% accrual × ${benefitRate} = ${amount} (Plan {plan})"`.
8. Idempotent ledger upsert: key = `"sla:{workerId}:{year}"`, plugin id = `"gbhet-pension-sla-hourly"`, dated December 31 of the year, booked to the configured SLA output account on the worker's `(entity_type=worker, entity_id=workerId)` EA.

R2.5 A persistent `gbhet_pension_annual_summary` table exists for staff-curated per-year records (totalPensionHours, accrualPct, benefitRate, monthlyBenefitRate, annualAccrual, qualified, classificationId, isSpecialDesignation; uniqueness on `(workerId, year)`). It is **maintained via the admin annual-summaries endpoints**, not auto-written by `computeSlaForWorker`. Its `qualified` flag drives the `qualifiedYears` count returned by the worker pension summary; treat any auto-population as a separate follow-up feature, not a requirement of SLA computation.

## R3. Contribution-Percent Accrual (2019+ style)

R3.1 The hourly-charge plugin (`gbhe-hourly-charge`) writes employer-charged ledger entries on the configured "trigger account" whenever hours are saved. Settings: `accountId` (the trigger account), `chargeTo` (`worker` or `employer`, default `employer`), optional `employmentStatusIds` filter, optional `specialDesignationMemberStatusIds`, `specialDesignationMonthlyHours` (default 135), and a `rateHistory` array of `{effectiveDate: YYYY-MM-DD, rate: number}` (at least one entry).

R3.2 The SLA-contribution plugin (`gbhet-pension-sla-contribution`) listens on `LEDGER_ENTRY_SAVED`. Activation guards (in order):

1. Skip if the entry's chargePlugin equals its own plugin id (avoid self-trigger loops).
2. Resolve trigger account ID and SLA output account ID from variables. Skip cleanly if either is unset.
3. Skip if `entry.accountId !== triggerAccountId`.
4. Skip if `entry.entityType !== "employer"`.
5. Look up the plan year for `entry.date.getFullYear()`. Skip if missing or not `accrualMethod === "contribution_pct"`.
6. On `changeType === "deleted"`, delete the prior derived entry (idempotent).

R3.3 Contribution percentage selection:

- Resolve a worker ID from `entry.data.workerId` if present, else from `(referenceType ∈ {hour, hour_adjustment}, referenceId)` via `workerHours.getWorkerHoursById`.
- If a worker resolves and the plugin config's `specialDesignationMemberStatusIds` is non-empty and intersects `worker.denormMsIds`, use `specialDesignationContributionPct ?? contributionPct ?? 0`. Otherwise use `contributionPct ?? 0`.
- If the resolved percent is 0, skip with reason.

R3.4 Compute `slaAmount = sourceAmount × pct / 100` (2-decimal). Memo: `"VDB SLA Contribution {year}: ${sourceAmount} × {pct}% ({special|regular}) = ${slaAmount}"`. Charge plugin key = `"{configId}:sla-contrib:{sourceEntryId}"`. Book to the SLA output account on the worker's EA. If no worker resolved on a fresh entry, skip rather than create.

R3.5 Idempotency: when the derived entry already exists with the same amount + memo, skip; if either changed, update with new metadata.

R3.6 The variable-contribution plugin (`gbhet-pension-variable-contribution`) listens on `LEDGER_ENTRY_SAVED`. Guards:

1. Skip self-triggered entries.
2. Skip entries whose `chargePlugin !== "gbhet-pension-sla-contribution"`.
3. Resolve source and target account IDs from variables. Skip if either unset.

R3.7 For each qualifying SLA-contribution entry, look up the **start-of-year share value** from the plan-year row's `shareValue` field. If the plan year has no `shareValue` (or it is ≤ 0), skip with a clear reason — there is no automatic fallback to the `gbhet_pension_share_values` table for share conversion. Compute `shares = slaAmount / shareValue` (round to 6 decimals). Book to the variable-contribution target account on the worker's EA, with a chargePluginKey of the form `"{configId}:var-contrib:{sourceEntryId}"`. Idempotent updates as above.

R3.8 Manual reconciliation also processes pre-2019 SLA entries. The batch reconciliation service (`reconcileVariableContributionForWorker`/`...ForAllWorkers`, exposed via the SLA compute endpoints) iterates **both** `gbhet-pension-sla-contribution` entries (2019+) and `gbhet-pension-sla-hourly` entries (pre-2019) and converts each into shares, using the same plan-year `shareValue` rule. This is what allows tiered-year accruals to also accumulate VDB shares when the plan years for those years have a `shareValue` configured. The plugin chain alone (R3.6) only acts on the contribution_pct path.

## R4. Share Values

R4.1 `gbhet_pension_share_values` stores `(effectiveDate: YYYY-MM-DD, shareValue numeric(12,6))` with uniqueness on `effectiveDate`. The "current value as of date D" is the most recent row with `effectiveDate <= D`.

R4.2 Share values are read at three different points; do not conflate them:

- **Variable contribution conversion** uses the start-of-year share value for the entry's year.
- **Worker pension summary / Variable benefit** at any point uses the current share value as of `today`.
- **Calculator at DoBC** uses the share value as of DoBC.

## R5. Worker Pension Summary (read endpoint)

R5.1 `getWorkerPensionSummary(workerId)` returns:

- `workerId`, `workerName`, `dateOfBirth`
- `totalShares` — balance of the worker's EA on the variable-contribution target account, "0.00" if missing
- `totalSla` — balance on the SLA output account, "0.00" if missing
- `currentShareValue` — for today
- `accumulatedBenefit` — `(totalShares × currentShareValue).toFixed(2)` if both nonzero, else "0.00". (Note: the summary endpoint surfaces variable benefit, not the `max(variable, SLA)` — that comparison happens inside the calculator.)
- `qualifiedYears` — count of plan years for which the worker has an annual-summary row with `qualified = true`
- `earlyRetirementReasons` — list of all configured reason codes (the UI exposes them as a dropdown)
- `availableElectionTypes` — fixed list `["life","5cc","lump","lumpearly","50js","75js","100js"]`

## R6. Per-Worker SLA Summary (admin/staff endpoint)

R6.1 `GET /api/sitespecific/gbhet/pension/sla/worker/:workerId` returns one row per plan year (descending), each row tagged with `accrualMethod`. For `tiered` years: includes computed totalHours, matching tier, accrualPct, plan, benefitRate, qualified, qualificationThresholdHours, plus `sharesEarned` if any (rare for pre-2019 years). For `contribution_pct` years: includes totalHours, contributionPct, contributionTotal (sum of SLA-contribution entries on the SLA account for that year), and `sharesEarned` (sum of variable-contribution entries on the share-target account for that year), plus `qualified`/`qualificationThresholdHours`.

R6.2 This endpoint is read-only and does not write or recompute ledger entries.

## R7. Actuarial Factor Tables (admin upload)

R7.1 Four factor tables, each independently importable from CSV/TSV:

- **AI factors** — `(age int unique, factor numeric(20,6))`. Used for both 70.5 and DoT-to-DoBC AI interpolation.
- **Payout factors** — `(electionType varchar, subscriberAge int, beneficiaryAge int nullable, factorYear int default 0, factor numeric(12,6))` with uniqueness on the four-tuple. `factorYear` is 0 for non-year-based types (life, 5cc, JS); year-based types (`lump`, `lumpearly`) require a non-zero factor year.
- **Early retirement factors** — `(reason varchar unique, monthlyFactor numeric(12,8))`. Reason is a free-text code (e.g. "disability", "voluntary30").
- **Interest rates** — `(year int unique, rate numeric(12,8))` — annual decimal rate (0.045 = 4.5%).

R7.2 CSV import endpoints accept a `clearExisting` boolean and validate every row; per-row errors are reported with row number and message, but valid rows still import (best-effort upsert).

R7.3 Payout factor import has a "single type" mode (POST `/factors/payout/import` with `electionType` and optionally `factorYear`) and a "bulk multi-type" mode (POST `/factors/payout/bulk-import` with rows that each carry their own `electionType`/`factorYear`/`beneficiaryAge`). The bulk frontend uses a column-mapping wizard with auto-detection.

R7.4 Election-type aliases must be normalised on bulk import: `"5-year certain & continuous" → "5cc"`, `"50% joint & survivor" → "50js"`, etc. Reject unknown election types with a clear per-row error.

## R8. Payout Calculator — `computeAllPayouts`

R8.1 Inputs: `workerId` (required), `dobc` (required, YYYY-MM-DD), `dot` (optional), `paymentDate` (optional), `earlyRetirementReason` (optional), `factorYear` (optional, defaults to `dobc.year`), `spouseDob` (optional; when present, JS election types are included), `normalRetirementAge` (optional, default 65).

R8.2 Required worker data: contact must have `birthDate`, else throw "Worker does not have a date of birth on file". Worker name = `firstName + " " + lastName`.

R8.3 Compute `subscriberAge = ageAtDate(dob, dobc)` and (if `spouseDob`) `beneficiaryAge`. Read `totalShares`, `currentShareValue` (as of DoBC), `totalSla`. Set `variableBenefit = totalShares × currentShareValue`.

R8.4 70.5 eligibility: compute `seventyHalfDate = dob + 70y6m`, `mrd = April 1 of (seventyHalfDate.year + 1)`, `endDate = dot ? dot : dobc`. Eligible iff `endDate >= mrd`.

R8.5 If 70.5 applies:

- Build the AI date series: `[mrd, January 1 of each subsequent year up to truncated end date]`. Truncated end date = `endDate` set to day = 1 of its month. If the truncated end date is strictly later than the last January 1 in the series, append it.
- For each AI date, compute `(ageY, ageM)` of the worker, the **interpolated AI factor** = `(factor[ageY] × (12 − ageM) + factor[ageY+1] × ageM) / 12`, then `aiRatio = (prevInterpolatedFactor / currentInterpolatedFactor) − 1` (zero on the first iteration). The earned annuity for this step = `aiRatio × (totalAnnuity + runningTotalAnnuity)` and similarly for shares; running totals accumulate. (Yes, the formula uses *previous* over *current* — this is intentional for the GBHE actuarial model.)
- After the loop: `accruedAnnuity = totalAnnuity + runningTotalAnnuity`, `accruedShares = totalShares + runningTotalShares`, `accruedShareValue = accruedShares × shareValueAtDoBC`. The 70.5 total is `max(accruedAnnuity, accruedShareValue)`; record which side won as `ai705Source ∈ {"annuity","share"}`.

R8.6 If `endDate < mrd`, 70.5 does not apply: `accumulatedBenefit = max(variableBenefit, totalSla)` and `accumulatedBenefitSource ∈ {"variable","sla"}`. (When 70.5 does apply, the source is `ai705_annuity` or `ai705_share` respectively.)

R8.7 If `dot` is present, also compute DoT-to-DoBC AI:

- `startDate = max(dob + normalRetirementAge years, dot)`. If `startDate >= dobc`, AI does not apply.
- Interpolated factors at `(startDate)` and `(dobc)`. `aiRatio = (startFactor / endFactor) − 1`. Earned amounts apply once (not iterative).
- Inputs to this AI are the post-70.5 accrued amounts when 70.5 applied, otherwise raw `totalSla` / `totalShares`.
- The result becomes the new `accumulatedBenefit` (and source flips between `sla`/`variable` according to the winning side).

R8.8 Build per-year accrual rollup `perYearAccruals: [{year, plan, annuity, shares}]` from the worker's annual-summary rows that either qualified or have non-zero annual accrual (used for UI display only; not part of the math).

R8.9 Early retirement reduction: when `earlyRetirementReason` is set and `subscriberAge < normalRetirementAge`, look up the per-month reduction factor for that reason. `monthsEarly = max(0, (normalRetirementAge-th-birthday − DoBC) in whole months by year/month subtraction)`. `adjustment = max(0, 1 − monthlyFactor × monthsEarly)`, formatted to 6 decimals.

R8.10 Election iteration: always include `["life","5cc","lump","lumpearly"]`; include `["50js","75js","100js"]` only if `beneficiaryAge` was computed. For each election:

- Look up the payout factor with `(electionType, subscriberAge, isJS ? beneficiaryAge : null, isLump ? factorYear : 0)`. Missing factor → result row carries an `error` like `"No payout factor found for age 64, year 2026"`.
- Lump: `finalAmount = accumulatedBenefit × payoutFactor`. (Early retirement adjustment is **not** applied to lump types.)
- Monthly: `finalAmount = (accumulatedBenefit × payoutFactor × earlyAdjustment) / 12`.

R8.11 Lump-sum eligibility: `monthlyLifeBenefit = result.find(electionType === "life").finalBenefitAmount`; `lumpSumEligible = monthlyLifeBenefit <= 100`. (Workers above $100/month must take an annuity.)

R8.12 Lump interest: when `paymentDate` is set, `lumpSumEligible` is true, and `monthsBetween(dobc, paymentDate) > 0`, look up the interest rate for `dobc.year`. `monthlyRate = annualRate / 12`. For each lump-type result with no error: `interestAmount = finalAmount × monthlyRate × months`; populate `interestRate`, `interestMonths`, `interestAmount`, `finalAmountWithInterest`. If no interest rate row exists for the year, skip silently.

R8.13 Output includes a `breakdown: string[]` of human-readable computation steps, suitable for direct display in the UI without further formatting. The detailed AI year-by-year tables are returned separately on `ai705.yearDetails` and `dotToDobcAI.yearDetails`.

## R9. Single-Election Calculator — `computePayout`

R9.1 A simpler endpoint that computes one election type at a time. Differences from `computeAllPayouts`:

- Does not apply the 70.5 or DoT-to-DoBC AI. `accumulatedBenefit = max(variableBenefit, totalSla)`.
- No lump interest.
- Returns the same shape as one row of `computeAllPayouts.results` plus `breakdown`.

This endpoint is provided for backwards compatibility and ad-hoc lookups. The UI uses `computeAllPayouts`.

## R10. Configuration Variables

R10.1 Four `storage.variables` keys hold ledger account IDs, set via admin endpoints (PUT `/sla/config` and PUT `/variable-contribution/config`):

- `gbhet_pension_sla_account_id` — output account for SLA dollar entries (both pre-2019 SLA and contribution-pct SLA)
- `gbhet_pension_sla_trigger_account_id` — input/trigger account watched by the SLA-contribution plugin
- `gbhet_pension_var_contrib_source_account_id` — input account for the variable-contribution plugin (typically the SLA account)
- `gbhet_pension_var_contrib_target_account_id` — output account for VDB shares

R10.2 The accounts must already exist in the ledger; the PUT endpoints validate the ID resolves to a real account before persisting. They also clear the in-process account ID caches.

R10.3 All four are stored as variable values. The reference defensively strips wrapping quotes (`replace(/^"|"$/g, "")`) when reading because some legacy variable values are JSON-encoded strings. New target implementations may either store unquoted strings or replicate this quote-stripping.

## R11. Component Gating

R11.1 All admin and staff endpoints under `/api/sitespecific/gbhet/pension/...` must be gated by both `requireAuth` and `requireComponent("sitespecific.gbhet.pension")`. Mutating endpoints additionally require `requirePermission("admin")`. Read-only worker summaries can use `requirePermission("staff")`.

R11.2 Each route must check `tableExists()` before reading/writing pension tables and respond 503 with a clear message when the component is enabled but tables haven't been provisioned yet (allows graceful onboarding).

R11.3 The hourly-charge plugin requires only `sitespecific.gbhet`; the two pension plugins additionally require `sitespecific.gbhet.pension`.

## R12. UI Surfaces

R12.1 Admin pages at:

- `/sitespecific/gbhet/pension/benefit-schedules` — CRUD for `(year, plan, monthlyBenefitRate)`.
- `/sitespecific/gbhet/pension/accrual-tiers` — CRUD for `(year, minHours, accrualPct)`.
- `/sitespecific/gbhet/pension/plan-years` — CRUD for plan-year config.
- `/sitespecific/gbhet/pension/employer-plans` — assign plan A/B to employers.
- `/sitespecific/gbhet/pension/actuarial-factors` — tabbed UI for AI / Payout / Early Retirement / Interest Rate factor tables, with CSV paste import dialogs and a column-mapping wizard for bulk payout imports.
- `/sitespecific/gbhet/pension/payout-calculator` — the VDB Payout Calculator: worker search → pension summary card → input form (DoBC, DoT, payment date, spouse DOB, early retirement reason, factor year) → results card with monthly + lump tables + AI year details + breakdown.

R12.2 Worker-facing page at `/workers/:id/vdb-pension`: read-only display of the worker's pension summary (shares, SLA, accumulated benefit, qualified years) and per-year SLA history.

R12.3 All interactive elements carry `data-testid` attributes following the `{action}-{target}` / `{type}-{content}` pattern (e.g. `button-calculate`, `input-dobc`, `select-early-retirement`).
