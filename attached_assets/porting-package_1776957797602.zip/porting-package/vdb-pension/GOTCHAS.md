# VDB Pension — Gotchas, Surprises, and Things You Will Get Wrong

A list of the non-obvious behaviours, error-prone defaults, and "this took two hours to debug" moments. Read it before you start, then re-read it when something doesn't behave the way the formula seems to say it should.

## G1. The AI ratio uses *previous over current*, not current over previous

`aiRatio = (prevInterpolatedFactor / currentInterpolatedFactor) − 1` — and yes, this is the correct order for the GBHE actuarial model. Many actuarial texts present AI as `(currentAge / olderAge) − 1` going *forward* in age; here factors are constructed so that the table values *decrease* as age advances (older = closer to payout), and the AI is realised as the *increase* in present-value relative to deferring further. Reversing the ratio silently flips the sign of every AI step. There are no protective clamps.

## G2. The factor for an exact age uses two table rows and weights by *months* (not days)

`interpolated(Y years M months) = (factor[Y] × (12 − M) + factor[Y+1] × M) / 12`. Day-of-month is ignored. If you implement day-precision interpolation you'll get tiny but persistent disagreements with the reference. The age-at-date helper that produces `(Y, M)` rolls under by one month if `at.getDate() < dob.getDate()` (so `1960-01-15` evaluated at `2025-01-10` is 64y 11m, not 65y 0m).

## G3. MRD is April 1 of the year *after* the worker turns 70½ — not the day after the half-birthday

The "70.5 year-month" date is `dob + 70 years + 6 months`. Then `mrdYear = seventyHalfDate.getFullYear() + 1` and `MRD = ${mrdYear}-04-01`. Using the half-birthday itself as MRD will give wrong answers for everyone.

## G4. The end date for 70.5 AI is *truncated to month-start* before being used

`termTruncated = (year, month, 1)`. The AI date series is `[mrd, jan-1 of mrd-year+1, jan-1 of mrd-year+2, …, ≤ termTruncated]`, with `termTruncated` appended as a final entry only if it isn't already the last one. A DoT of `2027-04-15` and a DoT of `2027-04-01` produce the same AI series; a DoT of `2027-05-01` adds one more step.

## G5. 70.5 AI inputs are *raw SLA dollars* and *raw shares*, not the `max(variable, SLA)` accumulated benefit

Inside `compute705ActuarialIncrease` the inputs are `slaNum` (annuity) and `sharesNum`. The "max" pick happens only *after* AI runs — the source ends as `ai705_annuity` or `ai705_share` based on which side was greater after AI. Confusingly, when 70.5 doesn't apply, the source is just `variable`/`sla`. There is no "ai705_variable" enum.

## G6. DoT-to-DoBC AI consumes the *post-70.5* accruals when both apply

If 70.5 AI ran with `applies: true`, the inputs to DoT-to-DoBC AI are `ai705Result.accruedBenefitAnnuity` and `ai705Result.accruedBenefitShare`. The `breakdown` calls this out explicitly. If you accidentally pass the raw totals you'll lose the 70.5 increase.

## G7. The `accumulatedBenefitSource` after DoT-to-DoBC AI is mapped peculiarly

The reference sets `accumulatedBenefitSource = dotToDobcAIResult.dotToDobcSource === "annuity" ? "sla" : "variable"`. That is, after DoT-to-DoBC AI the "source" string collapses back to `sla`/`variable` rather than introducing `dot_to_dobc_*` enum values. This is intentional for UI compatibility — but it does mean a calculation that ran 70.5 AI followed by DoT-to-DoBC AI will look like `sla` or `variable` in the source field, not `ai705_*`. If you preserve the AI distinction in the target, decide consciously whether to keep this collapsing behaviour or extend the enum.

## G8. Early retirement reduction is not applied to lump sums

Even when `earlyRetirementReason` is set and there's a real reduction factor, `lump` and `lumpearly` results compute `accumulatedBenefit × payoutFactor` only. Monthly types are `(accumulatedBenefit × payoutFactor × earlyAdjustment) / 12`. The two lump types have their own factor table values; the early-retirement *factor table* is for monthly streams.

## G9. Lump-sum eligibility is based on the *Life Annuity* result, not the worker's age or election

`lumpSumEligible = monthlyLifeBenefit ≤ 100`. Even if the worker explicitly elects `lump`, no interest is added unless the Life Annuity equivalent is at or below $100/month. The threshold lives in code (`100`) and is not configurable in the reference. If you make it configurable in the target, surface it to admins.

## G10. The SLA-contribution plugin requires `entityType === "employer"` on the trigger entry

If your hourly-charge plugin is configured with `chargeTo: "worker"`, the trigger entries will be `entityType: "worker"` and the SLA-contribution plugin will silently skip them ("Entry not for employer entity, skipping"). The chain only works when hours charges go to the employer entity. Document this loudly to admins; this is the most common "why aren't shares accruing?" support call.

## G11. Worker ID resolution from a trigger entry is fallible

The SLA-contribution plugin first tries `entry.data.workerId`, then falls back to looking up the hour record by `(referenceType ∈ {hour, hour_adjustment}, referenceId)`. If neither works, the plugin skips the entry with reason "Could not resolve worker ID from entry, skipping". If your hourly-charge plugin doesn't write `data.workerId`, audit the chain end-to-end on first run.

## G12. The variable-contribution plugin keys by *source SLA-contribution entry id*, not by worker+year

That means a single year can have many variable-contribution entries (one per source entry) — and they sum at read time. If you "fix" this by aggregating per-year, you'll break idempotency for late-arriving / amended source entries. Leave the per-source-entry granularity intact.

## G13. The variable-contribution plugin uses the *start-of-year* share value from the plan year — there is no fallback

Conversion is `shares = slaAmount / planYear.shareValue`. If a 2024 trigger entry is processed in 2025, the conversion still uses the start-of-year share value stored on the 2024 plan-year row. **There is no fallback to the `gbhet_pension_share_values` table** for share conversion — that table feeds the calculator (current value, value at DoBC) only. If a plan year's `shareValue` is null or zero, the variable-contribution plugin and the reconciliation service both skip the entry with a clear reason. Admins must set `shareValue` on every plan year that should accumulate shares (including pre-2019 tiered years if you want their SLA to convert into shares via reconciliation — see G26).

## G14. The four account-ID variables may be JSON-quoted in legacy installs

The reference defensively strips wrapping `"` characters: `value.replace(/^"|"$/g, "").trim()`. If your variables store always returns clean strings, you can drop the strip. If you store JSON-encoded values, replicate it. Either way, audit all four read sites: `gbhet-pension-sla.ts` (twice — output and trigger), `gbhetPensionSlaContribution.ts`, `gbhetPensionVariableContribution.ts`, and `gbhet-pension-payout-calculator.ts`.

## G15. Plan year `shareValue` is for the variable-contribution plugin, not for the calculator

The calculator uses `gbhet_pension_share_values.getCurrentValue(dobc)`. The plan year's `shareValue` field exists for the variable-contribution plugin's start-of-year conversion. Don't conflate them: an admin updating the plan-year share value will not change calculator quotes; conversely, adding share-value rows mid-year does not retroactively change shares already booked.

## G16. The calculator's "accumulated benefit" displayed on the worker summary endpoint is *just* shares × current value

`getWorkerPensionSummary` does not apply the SLA floor, AI, or anything else. It is `totalShares × currentShareValue`. The "max(variable, SLA)" pick happens only inside `computePayout`/`computeAllPayouts`. Do not "fix" the summary to show the floor unless the user asks — the calculator is the source of truth and the summary is intentionally lighter.

## G17. Annual summary rows are not auto-created by the SLA computation

`computeSlaForWorker` writes ledger entries but does not insert/update `gbhet_pension_annual_summary` rows. Those exist as a separate concept (admin-curated record of qualification + accrual) used by `qualifiedYears` counting and the `perYearAccruals` UI rollup. If you intend the summary table to be auto-maintained, that's a follow-up, not a requirement.

## G18. The payout factor table's `factorYear` defaults to 0 — and that 0 is meaningful

For non-year-based election types (life, 5cc, 50js, 75js, 100js), every row has `factorYear = 0`. The unique constraint includes `factorYear`. If you accidentally insert a `(life, 65, null, 2026)` row alongside `(life, 65, null, 0)`, the lookup using `effectiveFactorYear = 0` for life-type calls will not find the 2026 row — but you'll have two rows for the same logical factor and the UI will display both. Validate on import that non-year-based types always carry `factorYear = 0`.

## G19. Imports are best-effort, not transactional

Per-row failures are recorded and reporting continues. Successful rows commit even if later rows fail. This is intentional — admins want partial progress on large CSVs — but a re-import with the same CSV after fixing errors will only `created`/`updated` the previously-failing rows because the others are now upserts that match. Don't be alarmed by a `created: 1, updated: N` response on the second pass.

## G20. The early-retirement `monthsEarly` calculation uses whole-month subtraction

`monthsDiff = (normalRetDate.year − dobcDate.year) × 12 + (normalRetDate.month − dobcDate.month)`. Day-of-month is ignored. So a DoBC of `2024-12-31` and a 65th birthday of `2025-01-01` produces `monthsEarly = 1`, not 0 or `1/365`. This is consistent with the actuarial convention (months early, not days) but surprises engineers used to date-arithmetic libraries that would say "1 day".

## G21. The single-election `computePayout` is not the same math as `computeAllPayouts`

`computePayout` does not apply 70.5 or DoT-to-DoBC AI and does not apply lump interest. It exists for backward compatibility and ad-hoc use. The UI uses `computeAllPayouts`. If you build a "single election" UI in the target, prefer running `computeAllPayouts` and filtering the results array, so the math stays consistent across surfaces.

## G22. Memo strings are part of the contract for idempotency

Both the SLA service and the SLA-contribution plugin compare `existingEntry.memo !== description` to decide whether to update. If you change the memo format (e.g. localising the dollar sign or rounding differently), every single existing entry will be rewritten on the next run. That's not data corruption, but it is a noisy audit log and it will look like a bug to admins. Plan memo-format changes deliberately.

## G23. The hourly-charge plugin's special-designation logic uses **fixed monthly hours** (default 135), not actual hours

For workers identified as special-designation, the plugin charges as if they worked exactly `specialDesignationMonthlyHours` per month. Their actual reported hours are ignored for the charge amount. This applies only to the hourly-charge plugin, not to pension accrual qualification.

## G24. "Contribution % is 0" is an explicit skip path

If a plan year has `contributionPct: null` or `"0"` and the worker is not special-designation (or `specialDesignationContributionPct` is also 0), the SLA-contribution plugin returns `skipped` with reason "Contribution rate is 0%". This will look identical to "trigger account not configured" to anyone reading logs at a glance. The reasons are different — surface them clearly in your monitoring dashboards.

## G26. The batch reconciliation also converts pre-2019 SLA-hourly entries into shares

The `LEDGER_ENTRY_SAVED` plugin chain (R3.6) only runs on `gbhet-pension-sla-contribution` entries. But the manual reconciliation service (`reconcileVariableContributionForWorker`/`...ForAllWorkers`, invoked by the SLA compute endpoints) iterates **both** `gbhet-pension-sla-contribution` and `gbhet-pension-sla-hourly` entries on the source account and converts each to shares using `planYear.shareValue`. This is how pre-2019 tiered accruals end up with shares — but only after an admin runs SLA compute for the worker, and only if the relevant pre-2019 plan-year row has a `shareValue` configured. If a target implementation only ports the live plugin chain and skips the reconciliation service, pre-2019 share accumulation will silently never happen.

## G25. Tests should run with isolated chargePluginConfigId values

`chargePluginKey = "{configId}:sla-contrib:{sourceEntryId}"`. If two integration tests reuse the same source entry id with the same configId, the second test will see the first test's entry. Use unique configIds per test or unique source entry ids; the reference uses `"manual"` and `"batch"` as sentinel configIds for the compute endpoints.
