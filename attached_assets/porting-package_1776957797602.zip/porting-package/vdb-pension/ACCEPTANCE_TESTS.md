# VDB Pension — Acceptance Tests

These are scenario-level tests the target implementation must satisfy. They are written so the rebuilding agent can translate them into the target's own test harness (or run them by hand). Numeric tolerances allow rounding to the nearest cent unless noted.

## A. Plan Year & Tier Setup

A1. **Create a tiered plan year.** POST `/plan-years` with `{ year: 2018, accrualMethod: "tiered", qualificationThresholdHours: "500" }` → 201. Re-POST with the same year → 409.

A2. **Tier lookup picks highest-matching threshold.** Insert tiers `{2018, 0, 0}`, `{2018, 500, 50}`, `{2018, 1200, 100}`. A worker with 800 hours selects the 500-hour tier; 1500 hours selects the 1200-hour tier; 200 hours selects the 0-hour tier. (If your implementation treats minHours = 0 as "no accrual" rather than a real tier, A2 may select no tier; document the choice.)

A3. **Switching to contribution_pct.** POST `/plan-years` with `{ year: 2019, accrualMethod: "contribution_pct", contributionPct: "8.0", shareValue: "100.000000" }`. From this point on the SLA-contribution and variable-contribution plugins activate for 2019-dated entries.

## B. Pre-2019 SLA (tiered) accrual

B1. **Compute SLA for a worker.** Worker A has 1,300 hours in 2018; home employer is mapped to Plan A; the 2018 Plan A monthly benefit rate is `$50.00`; tier `(2018, 1200, 100)` matches. POST `/sla/compute/worker/{workerA.id}` returns `created: 1` for 2018 and the resulting ledger entry has `amount = "50.00"` (50 × 100/100), memo `"SLA 2018: 1,300 hrs → 100% accrual × $50.00 = $50.00 (Plan A)"`, dated `2018-12-31`, on the worker's EA on the SLA output account.

B2. **Re-running is idempotent.** Repeat B1 → `skipped: 1` with reason "Entry already matches expected values". The ledger has exactly one entry.

B3. **Editing tier triggers update.** Change tier `(2018, 1200)` accrualPct to `75`. Repeat B1 → `updated: 1`. Memo and amount reflect the new value; the entry id is unchanged.

B4. **Worker without home employer.** Worker B has hours but `denormHomeEmployerId = null`. SLA compute returns `skipped` with reason "Worker has no home employer assigned"; no ledger entry created.

B5. **Missing benefit schedule.** Worker C qualified for a tier in a year that has no `(year, plan)` benefit schedule. Compute returns `skipped` with reason "No benefit schedule found for year YYYY, Plan X"; no entry created.

## C. Contribution-percent (2019+) chain

C1. **Trigger entry creates SLA contribution.** With config from A3, write a ledger entry on the trigger account: `entityType="employer"`, `entityId=E1`, `date=2019-06-15`, `amount="100.00"`, `data: { workerId: "W1" }`. The SLA-contribution plugin then creates an entry on the SLA output account on W1's EA, `amount="8.00"`, memo `"VDB SLA Contribution 2019: $100.00 × 8% (regular) = $8.00"`, chargePluginKey containing the source entry id.

C2. **Variable contribution converts SLA to shares.** Immediately after C1, the variable-contribution plugin creates an entry on the variable-contribution target account on W1's EA, `amount = "0.080000"` shares (8.00 / 100.000000), chargePluginKey of the form `"{configId}:var-contrib:{slaContribEntryId}"`. If the 2019 plan-year row has no `shareValue`, the plugin skips with a clear reason and no shares entry is created (no fallback to `gbhet_pension_share_values`).

C3. **Special designation uses higher rate.** Configure the SLA-contribution plugin's `specialDesignationMemberStatusIds` to include `MS-VIP`. Worker W2 has `denormMsIds: ["MS-VIP"]`. Plan year 2019 has `specialDesignationContributionPct = "10.0"`. Repeat C1 with `workerId: "W2"` → SLA contribution `amount = "10.00"`, memo includes `"(special)"`. Subsequent variable contribution → 0.100000 shares.

C4. **Self-trigger guard.** Reposting / saving the SLA-contribution entry itself does not produce another SLA contribution (chargePlugin guard). Reposting / saving a variable-contribution entry does not produce another (chargePlugin guard).

C5. **Update propagates.** Modify the trigger entry's amount to `"200.00"`; the SLA-contribution entry updates to `"16.00"` and the variable-contribution entry updates to `"0.160000"` shares — without creating duplicates.

C6. **Delete propagates.** Set the trigger entry to `changeType="deleted"`. The SLA-contribution and variable-contribution entries are deleted via their chargePluginKey lookups.

C7. **Account not configured = silent skip.** Unset `gbhet_pension_sla_account_id`. Saving a trigger entry does not error; the SLA-contribution plugin returns success with message "SLA accounts not configured, skipping".

## D. Worker Pension Summary

D1. **Empty worker.** A worker with no shares and no SLA returns `totalShares: "0.00"`, `totalSla: "0.00"`, `accumulatedBenefit: "0.00"`, `currentShareValue` from today's lookup, `qualifiedYears: 0`, `availableElectionTypes: ["life","5cc","lump","lumpearly","50js","75js","100js"]`.

D2. **Worker with shares only.** Setting share value today = `120.000000` and total shares = `0.500000` returns `accumulatedBenefit = "60.00"`.

D3. **qualifiedYears counts qualified annual summaries only.** Insert two annual summaries with `qualified: true`, one with `qualified: false` → `qualifiedYears: 2`.

D4. **earlyRetirementReasons mirrors the factor table.** Insert reasons `["disability","voluntary30"]` → those are returned in `earlyRetirementReasons`.

## E. Payout Calculator — basic monthly

E1. **Life Annuity at 65, no AI.** Worker DOB `1961-01-01`, DoBC `2026-01-01` → subscriberAge 65. SLA = `$50.00`/year, shares = 0. Payout factor `(life, 65, null, 0) = 0.060000`. Result for `life`: `accumulatedBenefit="50.00"`, `monthlyBenefit = (50 × 0.06) / 12 = 0.25`, `finalBenefitAmount = "0.25"`, `accumulatedBenefitSource = "sla"`, breakdown contains "(SLA floor used)".

E2. **Variable benefit beats SLA floor.** Same worker with `totalShares = 1.0`, share value at DoBC = `100.0`, SLA = `$50.00`. `variableBenefit = 100`, `accumulatedBenefit = 100`, source `variable`.

E3. **Joint & Survivor requires spouse DOB.** Without `spouseDob`, the result list does not include `50js/75js/100js`. With `spouseDob = "1963-01-01"`, beneficiaryAge = 63 and the three JS election types appear (factor lookups must succeed for them).

E4. **Missing payout factor surfaces an error per row.** Delete the `(life, 65, null, 0)` factor; `compute-all` returns the `life` row with `finalBenefitAmount: null` and `error: "No payout factor found for age 65"` (or the implementation's worded variant). Other rows still compute.

## F. Payout Calculator — Early Retirement

F1. **Reduction applies only below normal retirement age.** DoBC = 60th birthday, `earlyRetirementReason = "voluntary30"` with `monthlyFactor = 0.005`. `monthsEarly = 60`. `adjustment = 1 − 60×0.005 = 0.7`. Monthly Life Annuity = `accumulatedBenefit × payoutFactor × 0.7 / 12`.

F2. **Reduction not applied to lump sums.** Same scenario; `lump` and `lumpearly` rows do not multiply by 0.7.

F3. **No reduction at or above NRA.** Same `earlyRetirementReason` but DoBC = 65th birthday → `monthsEarly = 0`, no `earlyRetirementAdjustment` field populated.

## G. Payout Calculator — 70.5 AI

G1. **70.5 not eligible when DoBC < MRD.** DOB `1961-06-01`, DoBC `2026-12-01`. seventyHalf = `2031-12-01`, MRD = `2032-04-01`. DoBC < MRD → `ai705 = null` (or `applies: false`); `accumulatedBenefit = max(variable, SLA)`.

G2. **70.5 eligible when DoT >= MRD.** DOB `1955-06-01`, DoT `2027-04-01`, DoBC `2027-04-01`. seventyHalf = `2025-12-01`, MRD = `2026-04-01`. AI series = `[2026-04-01, 2027-01-01, 2027-04-01]` (truncated). For each step, factor interpolation runs and `aiRatio = (prev/curr) − 1` is applied to the running total (annuity and shares separately).

G3. **70.5 picks the greater side.** Construct factors and balances such that the AI-grossed annuity exceeds AI-grossed share value → `ai705Source = "annuity"`, `accumulatedBenefitSource = "ai705_annuity"`. Reverse the share value to flip to `ai705_share`.

G4. **Truncation rule.** If DoT = `2027-04-15`, truncated end date = `2027-04-01` (day-of-month set to 1). The series uses the truncated date.

## H. Payout Calculator — DoT-to-DoBC AI

H1. **Applies when DoT and DoBC straddle age 65 with deferral.** DOB `1959-01-01`, DoT `2024-06-01`, DoBC `2027-01-01`. `birthday65 = 2024-01-01`. `startDate = max(birthday65, DoT) = 2024-06-01`. AI ratio computed from interpolated factors at `2024-06-01` vs `2027-01-01`.

H2. **Inputs include 70.5 AI when both apply.** When 70.5 AI ran first, the DoT-to-DoBC AI inputs are `accruedBenefitAnnuity` and `accruedBenefitShare` (not the raw totals). The breakdown explicitly notes this.

H3. **Skipped when start >= end.** DoT `2030-01-01`, DoBC `2027-01-01` → start (2030) > end (2027); `dotToDobcAI.applies = false`; `accumulatedBenefit` is unchanged.

## I. Payout Calculator — Lump Sum + Interest

I1. **Lump sum factor lookup uses factorYear.** `lump` factor `(lump, 65, null, 2026)` distinct from `(lump, 65, null, 2025)`. Calculator with DoBC in 2026 uses the 2026 factor. With `factorYear = 2025` override, uses the 2025 factor.

I2. **Lump-sum eligibility threshold.** Monthly Life Annuity result = `$95` → `lumpSumEligible = true`. Monthly Life Annuity = `$120` → `lumpSumEligible = false`; lump rows still compute their `finalBenefitAmount` but no interest is applied even if `paymentDate` is given.

I3. **Interest accrues monthly.** DoBC `2026-01-01`, paymentDate `2026-04-15`, interest rate for 2026 = `0.06` (6%/yr). `monthsBetween` = 3 (April − January). For a `lump` result of `$1,000`: `interestAmount = 1000 × 0.005 × 3 = $15.00`; `finalAmountWithInterest = "1015.00"`.

I4. **No interest rate for year = silent skip.** Same scenario without an interest_rate row for 2026 → `interestRate`/`interestAmount` remain null on the result rows; no error.

## J. Actuarial Factor Imports

J1. **AI factor CSV import upserts by age.** Importing `"65,50000000\n66,47000000"` with `clearExisting: true` first wipes the table then inserts 2 rows. Re-importing the same CSV with `clearExisting: false` leaves count at 2 (upsert by unique age).

J2. **Payout factor bulk import normalises type aliases.** A CSV with `"life annuity,65,,,0.06"` produces a row with `electionType: "life"` after normalisation. Unknown types (`"foo,65,,,0.06"`) appear in the per-row error list and do not abort the rest of the import.

J3. **Lump-sum import requires factorYear.** Calling `/factors/payout/import` with `electionType: "lump"` and no `factorYear` → 400.

J4. **Per-row errors do not block valid rows.** A 5-row import with one invalid age returns `imported: 4, total: 5, errors: [{row: 3, message: ...}]`.

## K. Configuration & Component Gating

K1. **Component disabled = 503.** With `sitespecific.gbhet.pension` disabled, every `/api/sitespecific/gbhet/pension/*` route returns 503 with a clear message. No DB access happens.

K1a. **Tables missing when component enabled.** Drop one of the pension tables; the corresponding route returns 503 with a message asking to enable the component.

K2. **Admin-only endpoints reject staff.** A staff-permission user calling any `requirePermission("admin")` route gets 403 (or whatever the host's permission middleware returns); the SLA worker-summary read is allowed.

K3. **PUT config validates account IDs.** `PUT /sla/config` with an `accountId` that doesn't resolve to a ledger account returns 400 "Output ledger account not found"; valid IDs persist and clear the in-process caches.

K4. **Quote-stripping for legacy variable values.** Setting the variable value to `"\"abc-123\""` (with literal surrounding quotes) is read as `"abc-123"` by all four callers (SLA service, var-contrib plugin, payout calculator).

## L. UI smoke tests

L1. The VDB Payout Calculator page renders worker search → summary → input form → results without console errors. Disabled state of the Calculate button: enabled iff a worker is selected and DoBC is set.

L2. The Actuarial Factors page Payout tab supports CSV paste, column-mapping wizard auto-detection (election type / year / age / beneficiary age / factor), and a preview before import.

L3. Worker VDB Pension page (`/workers/:id/vdb-pension`) shows totals plus per-year history with both `tiered` and `contribution_pct` rows formatted distinctly.

---

When porting, expect to add a few additional regression tests as you discover edge cases in the host project's ledger or worker-hours implementations. The reference's `gbhet-pension-payout-calculator.ts` contains the exact arithmetic; treat any divergence as a bug and adjust the target implementation, not the test, unless the discrepancy reveals an ambiguity that should be resolved with the user.
