-- VDB Pension — Reference SQL DDL (PostgreSQL)
--
-- This is a framework-neutral DDL extract. The reference implementation uses
-- Drizzle ORM (see reference-code/shared/schema/sitespecific/gbhet-pension/schema.ts)
-- and the table/column shapes here mirror what Drizzle produces. Adapt to your
-- target ORM as needed; what matters is the column types, defaults, and unique
-- constraints (uniqueness is critical for upsert semantics in several places).
--
-- All numeric ranges below are deliberate, not arbitrary:
--   numeric(20, 6) on AI factors  — AI factor table values can be very large (>1e8) with 6dp precision.
--   numeric(12, 6) on share value  — share values are dollars with sub-cent precision.
--   numeric(12, 8) on monthly_factor / rate — early-retirement and interest rates are sub-percentage decimals.
--   numeric(10, 4) on accrual_pct  — supports e.g. 0.7500 for 0.75%.

-- ============================================================================
-- BENEFIT SCHEDULES — per-year, per-plan monthly benefit rate (pre-2019 model)
-- ============================================================================
CREATE TABLE gbhet_pension_benefit_schedules (
    id                   varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    year                 integer NOT NULL,
    plan                 varchar(1) NOT NULL DEFAULT 'A',
    monthly_benefit_rate numeric(12, 2) NOT NULL,
    data                 jsonb,
    CONSTRAINT gbhet_pension_benefit_schedules_year_plan_unique UNIQUE (year, plan)
);

-- ============================================================================
-- ACCRUAL TIERS — hours-based tiers used in tiered (pre-2019) accrual
-- ============================================================================
CREATE TABLE gbhet_pension_accrual_tiers (
    id           varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    year         integer NOT NULL,
    min_hours    numeric(10, 2) NOT NULL,
    accrual_pct  numeric(10, 4) NOT NULL,
    data         jsonb,
    CONSTRAINT gbhet_pension_accrual_tiers_year_hours_unique UNIQUE (year, min_hours)
);

-- ============================================================================
-- EMPLOYER PLAN ASSIGNMENTS — maps each employer to plan A or B
-- ============================================================================
CREATE TABLE gbhet_pension_employer_plans (
    id           varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    employer_id  varchar NOT NULL REFERENCES employers(id) ON DELETE CASCADE,
    plan         varchar(1) NOT NULL DEFAULT 'A',
    data         jsonb,
    CONSTRAINT gbhet_pension_employer_plans_employer_unique UNIQUE (employer_id)
);

-- ============================================================================
-- ANNUAL SUMMARY — one row per (worker, year) recording what was computed
-- ============================================================================
CREATE TABLE gbhet_pension_annual_summary (
    id                                varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    worker_id                         varchar NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
    year                              integer NOT NULL,
    total_pension_hours               numeric(10, 2) NOT NULL DEFAULT 0,
    classification_id                 varchar REFERENCES options_classifications(id) ON DELETE SET NULL,
    is_special_designation            boolean NOT NULL DEFAULT false,
    tier_id                           varchar REFERENCES gbhet_pension_accrual_tiers(id) ON DELETE SET NULL,
    accrual_pct                       numeric(6, 4),
    monthly_benefit_rate              numeric(12, 2),
    annual_accrual                    numeric(12, 2),
    qualified                         boolean NOT NULL DEFAULT false,
    qualification_threshold_hours     numeric(10, 2) NOT NULL DEFAULT 500,
    data                              jsonb,
    CONSTRAINT gbhet_pension_annual_summary_worker_year_unique UNIQUE (worker_id, year)
);

-- ============================================================================
-- PLAN YEARS — drives per-year accrual behaviour. NEVER hardcode the cutoff in code.
-- ============================================================================
CREATE TABLE gbhet_pension_plan_years (
    id                                          varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    year                                        integer NOT NULL,
    -- accrual_method ∈ ('tiered', 'contribution_pct')
    accrual_method                              varchar(20) NOT NULL,
    contribution_pct                            numeric(6, 4),
    special_designation_contribution_pct        numeric(6, 4),
    qualification_threshold_hours               numeric(10, 2) NOT NULL DEFAULT 500,
    special_designation_monthly_hours           numeric(10, 2) NOT NULL DEFAULT 135,
    -- start-of-year share value used by the variable-contribution plugin
    share_value                                 numeric(12, 6),
    notes                                       text,
    data                                        jsonb,
    CONSTRAINT gbhet_pension_plan_years_year_unique UNIQUE (year)
);

-- ============================================================================
-- ACTUARIAL INCREASE (AI) FACTORS — keyed by age, used in 70.5 + DoT-to-DoBC AI
-- ============================================================================
CREATE TABLE gbhet_pension_ai_factors (
    id      varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    age     integer NOT NULL,
    factor  numeric(20, 6) NOT NULL,
    data    jsonb,
    CONSTRAINT gbhet_pension_ai_factors_age_unique UNIQUE (age)
);

-- ============================================================================
-- PAYOUT FACTORS — election-type-specific factors keyed by ages and (for lump) year
-- election_type ∈ ('life','5cc','lump','lumpearly','50js','75js','100js')
-- factor_year is 0 for non-year-based types; required >0 for ('lump','lumpearly').
-- beneficiary_age is NULL for non-JS types.
-- ============================================================================
CREATE TABLE gbhet_pension_payout_factors (
    id                varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    election_type     varchar(20) NOT NULL,
    subscriber_age    integer NOT NULL,
    beneficiary_age   integer,
    factor_year       integer NOT NULL DEFAULT 0,
    factor            numeric(12, 6) NOT NULL,
    data              jsonb,
    CONSTRAINT gbhet_pension_payout_factors_type_ages_year_unique
        UNIQUE (election_type, subscriber_age, beneficiary_age, factor_year)
);

-- ============================================================================
-- EARLY RETIREMENT FACTORS — per-reason monthly reduction factor
-- ============================================================================
CREATE TABLE gbhet_pension_early_retirement_factors (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    reason          varchar(50) NOT NULL,
    monthly_factor  numeric(12, 8) NOT NULL,
    data            jsonb,
    CONSTRAINT gbhet_pension_early_retirement_factors_reason_unique UNIQUE (reason)
);

-- ============================================================================
-- INTEREST RATES — annual decimal rate used for lump-sum interest from DoBC to payment date
-- ============================================================================
CREATE TABLE gbhet_pension_interest_rates (
    id    varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    year  integer NOT NULL,
    rate  numeric(12, 8) NOT NULL,  -- annual rate as a decimal (0.045 = 4.5%)
    data  jsonb,
    CONSTRAINT gbhet_pension_interest_rates_year_unique UNIQUE (year)
);

-- ============================================================================
-- SHARE VALUES — point-in-time share unit value (effective_date stored as YYYY-MM-DD text)
-- ============================================================================
CREATE TABLE gbhet_pension_share_values (
    id              varchar PRIMARY KEY DEFAULT gen_random_uuid(),
    -- Stored as YYYY-MM-DD text to avoid timezone shifting (Ymd date pattern).
    effective_date  varchar(10) NOT NULL,
    share_value     numeric(12, 6) NOT NULL,
    data            jsonb,
    CONSTRAINT gbhet_pension_share_values_date_unique UNIQUE (effective_date)
);

-- ============================================================================
-- VARIABLES (host-codebase responsibility) — stored separately
-- The feature reads four configurable account IDs from a host variables/settings store:
--   gbhet_pension_sla_account_id
--   gbhet_pension_sla_trigger_account_id
--   gbhet_pension_var_contrib_source_account_id
--   gbhet_pension_var_contrib_target_account_id
-- These point at ledger accounts that already exist in the host's ledger tables.
-- ============================================================================
