# VDB Pension — API Contract

All endpoints live under `/api/sitespecific/gbhet/pension/` and require the `sitespecific.gbhet.pension` component flag. Auth as marked. Mutating endpoints respond 503 if the underlying tables don't exist yet (with a message asking to enable the component).

Conventions:

- Dates are `YYYY-MM-DD` strings unless noted.
- Numeric monetary values are decimal strings (e.g. `"123.45"`) to preserve precision.
- 400 = validation error; 401/403 = auth/permission; 404 = not found; 409 = unique-conflict; 503 = component disabled or tables missing; 500 = unexpected.

---

## Benefit Schedules

`requireAuth` for reads; `requireAuth + requirePermission("admin")` for writes.

- `GET  /benefit-schedules` → `BenefitSchedule[]`
- `GET  /benefit-schedules/year/:year` → `BenefitSchedule | 404`
- `GET  /benefit-schedules/:id` → `BenefitSchedule | 404`
- `POST /benefit-schedules` body `InsertBenefitSchedule` → 201 `BenefitSchedule` | 409 if `(year,plan)` exists
- `PATCH /benefit-schedules/:id` body partial `InsertBenefitSchedule` → `BenefitSchedule | 404 | 409`
- `DELETE /benefit-schedules/:id` → 204 | 404

`BenefitSchedule = { id, year, plan: "A"|"B", monthlyBenefitRate: string, data: object|null }`

## Accrual Tiers

Same auth shape as Benefit Schedules.

- `GET  /accrual-tiers` → `AccrualTier[]`
- `GET  /accrual-tiers/year/:year` → `AccrualTier[]`
- `GET  /accrual-tiers/:id` → `AccrualTier | 404`
- `POST /accrual-tiers` body `InsertAccrualTier` → 201 | 409 on `(year, minHours)` conflict
- `PATCH /accrual-tiers/:id` → `AccrualTier | 404 | 409`
- `DELETE /accrual-tiers/:id` → 204 | 404

`AccrualTier = { id, year, minHours: string, accrualPct: string, data }`

## Annual Summaries

- `GET  /annual-summaries/year/:year` → `AnnualSummary[]` (admin)
- `GET  /annual-summaries/worker/:workerId/year/:year` → `AnnualSummary | 404`
- `POST /annual-summaries` body `InsertAnnualSummary` → upsert by `(workerId, year)` → 201

`AnnualSummary` mirrors the table columns from SCHEMA.sql.

## Share Values

- `GET  /share-values` → `ShareValue[]`
- `GET  /share-values/current/:date` → `ShareValue | 404` (most recent row with `effectiveDate <= date`)
- `GET  /share-values/:id` → `ShareValue | 404`
- `POST /share-values` body `InsertShareValue` → 201 | 409 on date conflict
- `PATCH /share-values/:id` → `ShareValue | 404 | 409`
- `DELETE /share-values/:id` → 204 | 404

## Plan Years

- `GET  /plan-years` → `PlanYear[]`
- `GET  /plan-years/year/:year` → `PlanYear | 404`
- `GET  /plan-years/:id` → `PlanYear | 404`
- `POST /plan-years` body `InsertPlanYear` → 201 | 409
- `PATCH /plan-years/:id` → 200 | 404 | 409
- `DELETE /plan-years/:id` → 204 | 404

`PlanYear = { id, year, accrualMethod: "tiered"|"contribution_pct", contributionPct: string|null, specialDesignationContributionPct: string|null, qualificationThresholdHours: string, specialDesignationMonthlyHours: string, shareValue: string|null, notes: string|null, data }`

## Employer Plan Assignments

- `GET  /employer-plans` → `EmployerPlan[]`
- `GET  /employer-plans/:id` → `EmployerPlan | 404`
- `POST /employer-plans` body `InsertEmployerPlan` → 201 (upsert by employerId)
- `DELETE /employer-plans/:id` → 204 | 404

`EmployerPlan = { id, employerId, plan: "A"|"B", data }`

## SLA Configuration

- `GET  /sla/config` (admin) → `{ accountId: string|null, triggerAccountId: string|null, accounts: {id,name}[] }`
- `PUT  /sla/config` (admin) body `{ accountId?, triggerAccountId? }` → `{ success: true }`. Validates each ID resolves to a real ledger account; clears server-side caches.

## Variable Contribution Configuration

- `GET  /variable-contribution/config` (admin) → `{ sourceAccountId: string|null, targetAccountId: string|null, accounts: {id,name}[] }`
- `PUT  /variable-contribution/config` (admin) body `{ sourceAccountId?, targetAccountId? }` → `{ success: true }`

## SLA Computation (idempotent)

- `POST /sla/compute/worker/:workerId` (admin) body `{ configId? }` → `SlaBatchResult & { contributionResult?, varContribResult? }`. Iterates all `tiered` plan years for one worker, then reconciles contribution-pct entries and variable-contribution shares for the worker.
- `POST /sla/compute/all` (admin) body `{ configId? }` → same shape, all workers.

`SlaBatchResult` shape: `{ processed, created, updated, skipped, errors, results: SlaCalculationResult[], errorDetails: string[] }`. See `reference-code/server/services/gbhet-pension-sla.ts` for the per-row shape.

## Per-Worker SLA Summary (read-only)

- `GET /sla/worker/:workerId` (staff) → array of per-year objects sorted by `year` descending. Each row carries `accrualMethod` and the appropriate fields:
  - tiered: `{ year, accrualMethod:"tiered", totalHours, accrualPct, benefitRate, plan, amount, qualified, qualificationThresholdHours, tierId, tierMinHours, sharesEarned, sharesEntryCount, shareValue }`
  - contribution_pct: `{ year, accrualMethod:"contribution_pct", totalHours, contributionPct, contributionTotal, contributionEntryCount, sharesEarned, sharesEntryCount, shareValue, plan, amount, qualified, qualificationThresholdHours }`

## Actuarial Factor Tables

All under `/factors`. AI/PayOut/Early-Retirement/Interest-Rate tables follow the same admin-CRUD shape; representative endpoints:

- `GET    /factors/summary` (admin) → `{ aiFactors:{count}, payoutFactors:{count, byType:Record<string,number>}, earlyRetirementFactors:{count}, interestRates:{count} }`
- `GET    /factors/ai` → `AiFactor[]`
- `POST   /factors/ai/import` (admin) body `{ rows: {age,factor}[], clearExisting?: boolean }` → `{ imported, total, errors?: {row,message}[] }`
- `DELETE /factors/ai/:id` (admin) → 204 | 404
- `GET    /factors/payout?electionType=life&factorYear=2026` → `PayoutFactor[]`
- `POST   /factors/payout/import` (admin) body `{ rows, electionType, factorYear?, clearExisting? }` → `{ imported, total, errors? }`. `factorYear` is required when `electionType` is `lump` or `lumpearly`.
- `POST   /factors/payout/bulk-import` (admin) body `{ rows: {electionType, subscriberAge, beneficiaryAge?, factorYear?, factor}[], lumpFactorYear?, clearExisting? }` → `{ imported, total, errors? }`. Election-type aliases (e.g. `"life annuity"`, `"50% joint & survivor"`) must be normalised on the server.
- `GET    /factors/early-retirement` (admin) → `EarlyRetirementFactor[]`
- `POST   /factors/early-retirement/import` (admin) body `{ rows, clearExisting? }` → standard import response
- `DELETE /factors/early-retirement/:id` (admin) → 204 | 404
- `GET    /factors/interest-rates` (admin) → `InterestRate[]`
- `POST   /factors/interest-rates/import` (admin) body `{ rows, clearExisting? }` → standard import response
- `DELETE /factors/interest-rates/:id` (admin) → 204 | 404

All `/factors/*` reads (including `/factors/ai`, `/factors/payout`) require `admin` permission in the reference. Lump-import bulk endpoint accepts a `lumpFactorYear` field at the top level only as a UI convenience for the column-mapping wizard; the server expects `factorYear` to be supplied per row for `lump`/`lumpearly` rows. Per-row election types are normalised against the alias table (`"life annuity"` → `"life"`, `"50% joint & survivor"` → `"50js"`, etc.).

## Payout Calculator

- `GET  /payout-calculator/worker/:workerId/summary` (admin) → `WorkerPensionSummary` (see REQUIREMENTS R5).
- `POST /payout-calculator/compute-all` (admin) body `ComputeAllInput` → `ComputeAllResult`. Inputs and result shape are spelled out in REQUIREMENTS R8 and visible in `reference-code/server/services/gbhet-pension-payout-calculator.ts` (interfaces `ComputeAllPayoutsInput`, `ComputeAllPayoutsResult`).
- `POST /payout-calculator/compute` (admin) body `PayoutInput` → `PayoutResult` — single-election variant per REQUIREMENTS R9.

Note: The reference gates the payout calculator endpoints behind `requirePermission("admin")`, even though the underlying `/sla/worker/:workerId` summary is `staff`-readable. Targets may relax to `staff` if their threat model allows; document the choice.

`ComputeAllInput`:

```ts
{
  workerId: string;            // required
  dobc: string;                // required, YYYY-MM-DD
  dot?: string|null;           // YYYY-MM-DD
  paymentDate?: string|null;   // YYYY-MM-DD
  earlyRetirementReason?: string|null;
  factorYear?: number|null;    // defaults to dobc year for lump factor lookup
  spouseDob?: string|null;     // when present, JS election types are included
  normalRetirementAge?: number; // default 65
}
```

The full `ComputeAllResult` shape is the canonical source of truth for the UI; see the TypeScript interfaces in the reference. Error responses:

- 400: `{ message: "Worker does not have a date of birth on file" }` and similar input-validation errors.
- 404: `{ message: "Worker not found" }`.
- The body's per-election `results[].error` field carries non-fatal errors like missing payout factors so the UI can show partial results.

## Worker-Facing Pension Summary

- `GET /workers/:workerId/vdb-pension` (staff) → composite of `WorkerPensionSummary` plus the per-year SLA summary (used to render the worker page). The reference uses two separate calls (`/payout-calculator/worker/:id/summary` and `/sla/worker/:id`); a target implementation may compose them.

---

For exact response shapes, defer to the TypeScript interfaces and Zod schemas in `reference-code/`. The reference file paths mirror those used in the source project.
